<?php
/**
 * Media Manager for Codeigniter
 *
 * @package    CodeIgniter
 * @author     Prashant Pareek
 * @link       http://codecanyon.net/item/media-manager-for-codeigniter/9517058
 * @version    2.3.1
 */
defined('BASEPATH') OR exit('No direct script access allowed');

$config['allowed_types'] = 'bmp,gif,ico,jpg,jpeg,odg,odp,ods,odt,png,swf';
$config['max_size'] = 10;
$config['max_width'] = 1920;
$config['max_height'] = 1080;
$config['media_path'] = 'media';
$config['max_filename'] = 0;
$config['max_files'] = 10;
$config['overwrite'] = 0;
$config['remove_spaces'] = 1;
$config['encrypt_name'] = 0;