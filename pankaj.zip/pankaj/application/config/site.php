<?php  
defined('BASEPATH') OR exit('No direct script access allowed');
/*
|--------------------------------------------------------------------------
| Site configuration
|--------------------------------------------------------------------------
| 'site_name'	     = The name to be displayed as site title
| 'admin_email'    = Email to be used to send system generated emails
*/

$config['site_name'] = 'Picture Perfect';
$config['admin_email'] = 'admin@gmail.com';