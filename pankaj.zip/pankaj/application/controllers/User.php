<?php
/**
 * Media Manager for Codeigniter
 *
 * @package    CodeIgniter
 * @author     Prashant Pareek
 * @link       http://codecanyon.net/item/media-manager-for-codeigniter/9517058
 * @version    2.3.1
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * User Class
 */
class User extends CI_Controller {
  
  /**
   * Constructor, initializes the libraries and model
   */
  public function __construct()
  {
    parent::__construct();               

    // load recaptcha library
    $this->load->library('recaptcha');

    // load form validation library
    $this->load->library('form_validation');

    // load user model 
    $this->load->model('user_model');
	
	if ($this->auth->loggedin()) 
	{ 
		$user = $this->user_model->get_logged_user($this->session->userdata('auth_user'));
		define("USER_NAME", $user->name);
		define("USER_IMAGE", $user->image);
		define("USER_ID", $this->session->userdata('auth_user'));
	}
	
  }

  /**
   * Default method of user class, redirect to media class if user is logged in,
   * else display login-registration page.
   */
  public function index()
  {           
    // check if user logged in (note: auth library is auto loaded)
    if ($this->auth->loggedin()) 
	{          
      // redirect user to media manager page  
		$data['success_message'] = $this->session->set_userdata('success_message', 'Successfully Logged In');          
		$meta['page_title'] = 'Dashboard';
		
		$this->load->view('commons/userheader', $meta);	
		$this->load->view('user/dashboard', $data);
		$this->load->view('commons/userfooter');
    }
    else
    {
      // display login-registration page          
      $data['page'] = 'user/login';
      $data['form'] = 'login';
      $this->load->view('index',$data);     
    }
  }
  
  	public function my_profile($id = NULL)
	{
		if(!$this->auth->loggedin())
		{
			redirect('user/index', 'refresh');
		}
		// get details
		if($id != NULL) 
		{
			$data['item'] = $this->user_model->get_item($id);
		}
		
		$data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));
		
		$data['page_title'] = 'My Profile';
		$meta['page_title'] = 'My Profile';
			
		$this->load->view('commons/userheader', $meta);		
		$this->load->view('user/edit_user', $data);
		$this->load->view('commons/userfooter');
	}
	
	public function change_picture($id = NULL)
	{
		if(!$this->auth->loggedin())
		{
			redirect('user/index', 'refresh');
		}
		
		if($this->input->get('id')) { $id = $this->input->get('id'); }
		
		$this->form_validation->set_rules('userfile', 'Change Image', 'trim');
		
		if ($this->form_validation->run() === TRUE)
		{
			if($_FILES['userfile']['size'] > 0){
				
				$this->load->library('upload');
				
				$config['upload_path'] = 'theme/uploads/images/'; 
				$config['allowed_types'] = 'gif|jpg|png|jpeg'; 
				$config['max_size'] = '100MB';
				$config['max_width'] = '4000';
				$config['max_height'] = '5000';
				$config['overwrite'] = FALSE; 
				
					$this->upload->initialize($config);
					
					if( ! $this->upload->do_upload('userfile')){
					
						$error = $this->upload->display_errors();
						$this->session->set_flashdata('message', $error);
						redirect("user/change_picture/".$id, 'refresh');
					} 
				
				$photo = $this->upload->file_name;
				
				$this->load->helper('file');
				$this->load->library('image_lib');
				$config['image_library'] = 'gd2';
				$config['source_image'] = 'theme/uploads/images/'.$photo;
				$config['new_image'] = 'theme/uploads/thumbs/'.$photo;
				$config['maintain_ratio'] = TRUE;
				$config['width'] = 29;
				$config['height'] = 29;
				
				$this->image_lib->clear();
				$this->image_lib->initialize($config);
				
				if ( ! $this->image_lib->resize())
				{
					echo $this->image_lib->display_errors();
					
				}
				
				} else {
					$photo = NULL;
				}
				
				$imgData = array(
					'image' 		=> $photo,
				);
		}
		
		if($this->form_validation->run() === TRUE && $this->user_model->changeProfilePicture($id, $imgData))
		{
			$this->session->set_flashdata('success_message', "Profile Picture Changed Successfully");
			redirect("user/index/", 'refresh');
		}
		else
		{
			$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
			$data['success_message'] = $this->session->flashdata('success_message');
			
			$meta['page_title'] = 'Change Avatar';
			$data['page_title'] = 'Change Avatar';
			$data['id'] = $id;
			
			$this->load->view('commons/userheader', $meta);

			$this->load->view('user/mysettings', $data);
			
			$this->load->view('commons/userfooter');
			
		}
	}
	
	public function change_password()
	{
		
		if(!$this->auth->loggedin())
		{
			redirect('user/index', 'refresh');
		}
		$this->load->library('form_validation');

		// set bootstrap error delimiter for registration form
		$this->form_validation->set_error_delimiters('<div class="has-danger"><small class="text-help">', '</small></div>');		

		// set validation rules
		$this->form_validation->set_rules('old_password', 'Old Password', 'trim|required|strip_tags|min_length[8]|max_length[32]');
		$this->form_validation->set_rules('new_password', 'New Password', 'trim|required|strip_tags|min_length[8]|max_length[32]');
		$this->form_validation->set_rules('conf_password', 'Password Confirmation', 'trim|required|strip_tags|matches[new_password]');

		$this->session->set_flashdata('cpassword.status',1);

		// if form validation fails	
		/*if($this->form_validation->run() == FALSE)
		{								
			$this->index();
			return false;			
		}*/

		// update user details
		$user_id = $this->session->userdata('auth_user');		
		if($this->form_validation->run() == TRUE && $result = (int) $this->user_model->update_password($user_id))
		{
		
			switch($result)
			{
				case -1: // invalid password
								 $msgerr = 'Invalid old password supplied';
								 $type = 'danger';
								 break;
	
				case 1:  // user details updated
								 $msg = 'User password updated successfully.';
								 $type = 'success';
								 break;
	
				case 0:  // could not update user details
				default: $msgerr = 'Could not update user password.';
								 $type = 'danger';
								 break;			
			}
			//$message = $this->base->set_message($msg,$type);

			$this->session->set_flashdata('success_message',$msg);
			$this->session->set_flashdata('message',$msgerr);

			redirect('user/index', 'refresh');
		}
		else
		{
			$data['message'] =  $this->session->flashdata('message');
			$data['success_message'] = $this->session->flashdata('success_message');
			
			$meta['page_title'] = 'Change Password';
			$data['page_title'] = 'Change Password';
			
			$this->load->view('commons/userheader', $meta);

			$this->load->view('user/change-password', $data);
			
			$this->load->view('commons/userfooter');	
		}
		
		// set change password notification
			
	}
  
  function customers() {
		
		/*if(!$this->auth->loggedin())
		{
			redirect('user/index', 'refresh');
		}*/
		
		$data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
		$data['success_message'] = $this->session->flashdata('success_message');
		
			//list the users
			$data['customers'] = $this->user_model->getAllCustomers();
			/*foreach ($data['users'] as $k => $user)
			{
				$data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
			}*/
			
			$meta['page_title'] = 'Customers';
			
			$this->load->view('commons/header', $meta);

			$this->load->view('user/index', $data);
			
			$this->load->view('commons/footer');
			
	}
	
	function add_address()
	{
		if(!$this->auth->loggedin())
		{
			redirect('user/index', 'refresh');
		}
		
		//$this->form_validation->set_rules('deladdress', 'Address', 'trim|required');
    	//$this->form_validation->set_rules('printype', 'Print Type', 'trim|required');
		$this->form_validation->set_rules('pincode', 'Postal code', 'trim|required');
		$this->form_validation->set_rules('city', 'City', 'trim|required');
		$this->form_validation->set_rules('title', 'Address Title', 'trim|required');
		
		if ($this->form_validation->run() == true)
		{
			$title = $this->input->post('title');
			$address = $this->input->post('address');
			$city = $this->input->post('city');
			$state = $this->input->post('state');
			$pincode = $this->input->post('pincode');
			
			$Addresses = array(
				'customer_id'	=> $this->session->userdata('auth_user'),
				'title'			=> $title,				
				'address' 		=> $address,
				'city'			=> $city,
				'state'			=> $state,
				'pincode'		=> $pincode				
			);
		}
		
		if($this->form_validation->run() == true && $this->user_model->addMoreAddress($Addresses))
		{
			//print_r($inv_deladdress);
			$this->session->set_flashdata('success_message', $this->lang->line("address_added"));
			redirect("user/add_order", 'refresh');
		}
		else
		{
		
			$meta['page_title'] 	= 'New Order';
			$data['page_title'] 	= 'New Order';
			//$data['rnumber'] = $this->user_model->getNextAI();
			$data['deliveryfees'] 	= $this->site->getAllDeliverycharges();
			$data['addresses'] 		= $this->site->getAllCustomerAddresses($this->session->userdata('auth_user'));
	   		$data['dimensions'] 	= $this->site->getAllDimesions();
			$this->load->view('commons/userheader', $meta);
			$this->load->view('user/add', $data);
			$this->load->view('commons/userfooter');
		}
	}
	
	function orders() 
	{
	
		if(!$this->auth->loggedin())
		{
			redirect('user/index', 'refresh');
		}
		
		$data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
		$data['success_message'] = $this->session->flashdata('success_message');
		
		$meta['page_title'] = 'My Orders';
		$data['page_title'] = 'My Orders';
		
		
		$this->load->view('commons/userheader', $meta);

		$this->load->view('user/orders', $data);
		
		$this->load->view('commons/userfooter');
			
	}
	
	function add_order()
	{
		if(!$this->auth->loggedin())
		{
			redirect('user/index', 'refresh');
		}
		
		//$this->form_validation->set_rules('deladdress', 'Address', 'trim|required');
    	//$this->form_validation->set_rules('printype', 'Print Type', 'trim|required');
		$this->form_validation->set_rules('date', 'Date', 'trim|required');
		//$this->form_validation->set_rules('deldate', 'Delivery Date', 'trim|required');
		$this->form_validation->set_rules('title', 'Print Title', 'trim|required');
		
		$dragndrop 		= "dragndrop";
		//$printype 		= "printype";
		$deladdress 	= "cuaddress";
		
		if ($this->form_validation->run() == true)
		{
			
			for($i=1; $i<=500; $i++){
					if($this->input->post($dragndrop.$i) && $this->input->post($printype.$i) && $this->input->post($deladdress.$i) ) {
						$inv_dragndrop[] = $this->input->post($dragndrop.$i);
						//$inv_printype[] = implode(",",$this->input->post($printype.$i));
						$inv_deladdress[] = $this->input->post($deladdress.$i);
					}
			}
			
			$date = date("Y-m-d",strtotime($this->input->post('date')));
			$deldate = date("Y-m-d",strtotime($this->input->post('deldate')));
			$title = $this->input->post('title');
			
			$orders = array(
				'order_no' 		=> $this->user_model->getNextAI(),
				'title'			=> $title,
				'customer_id'	=> $this->session->userdata('auth_user'),
				'customer_name' => USER_NAME,
				'order_date'	=> $date,
				'delivery_date'	=> $deldate				
			);
			
			/*$order_items = array(
				'pictures'		=> $inv_dragndrop,
				'address'		=> $inv_deladdress,
				'printtypes'	=> implode(",",$inv_printype)
			);*/
			
			$keys = array("pictures", "address", "printtypes");
		
			$items = array();
			foreach ( array_map(null, $inv_dragndrop, $inv_deladdress, $inv_printype) as $key => $value ) {
				$items[] = array_combine($keys, $value);
			}
		}
		
		if($this->form_validation->run() == true && $this->user_model->addPhotoPrinting($orders, $items))
		{
			//print_r($inv_deladdress);
			$this->session->set_flashdata('success_message', $this->lang->line("order_added"));
			redirect("user/orders", 'refresh');
		}
		else
		{
		
			$meta['page_title'] 	= 'New Order';
			$data['page_title'] 	= 'New Order';
			//$data['rnumber'] = $this->user_model->getNextAI();
			$data['deliveryfees'] 	= $this->site->getAllDeliverycharges();
			$data['addresses'] 		= $this->site->getAllCustomerAddresses($this->session->userdata('auth_user'));
	   		$data['dimensions'] 	= $this->site->getAllDimesions();
			$this->load->view('commons/userheader', $meta);
			$this->load->view('user/add', $data);
			$this->load->view('commons/userfooter');
		}
	}
	
	function getdimensions()
	{
		//$array = array("printing", "lamination", "framing");
		
		$printing1 = $this->input->post('printing1',TRUE);
		$lamination1 = $this->input->post('lamination1',TRUE);
		$framing1 = $this->input->post('framing1',TRUE);
		//$clid = $this->input->post('clid',TRUE);
		$section_id = $this->input->post('id',TRUE);
	
		if($rows = $this->site->getDimensionByID($section_id)) {
			
			if(!empty($printing1) && !empty($lamination1) && empty($framing1))
			{
				$data = $rows->printing + $rows->lamination;
			}
			if(!empty($printing1) && !empty($framing1) && empty($lamination1))
			{
				$data = $rows->printing + $rows->framing;
			}	
			if(!empty($printing1) && !empty($lamination1) && !empty($framing1))
			{
				$data = $rows->printing + $rows->lamination + $rows->framing;
			}
			if(!empty($lamination1) && !empty($framing1) && empty($printing1))
			{
				$data = $rows->lamination + $rows->framing;
			}	
			if(!empty($printing1) && empty($lamination1) && empty($framing1))
			{
				$data = $rows->printing;
			}	
		} else { 
			$data = "";
		}
		echo $data;
	}

  /**
   * Method to validate and allow user to login
   */
  function validate_credentials()
  {         
    // set validation rules for username and password fields
    $this->form_validation->set_rules('username', 'Username', 'trim|required');
    $this->form_validation->set_rules('password', 'Password', 'trim|required');
    
    // if form validation fails load login page   
    if ($this->form_validation->run() == FALSE)
    {       
      $this->index();
      return false;
    }
    
    // validate user    
    $result = $this->user_model->validate();

    switch($result)
    {       
      case 0: // Username or password field do not match                
              $this->base->set_message('Invalid username or password.','danger');
              break;
          
      case 1: redirect('user/index');                                  
              break;      
          
      case 2: // User's account is not activated yet.                 
              $this->base->set_message('Your account is not activated yet.','warning');           
              break;
      default: 
              break;  
    } 

    $this->index();

    return true;
  }

  /**
   * Method to logout user
   */
  function logout()
  {   
    $this->session->unset_userdata('path');
    $this->auth->logout();
    $this->index();
  }

  /**
   * Method to register user
   */
  public function register()
  {
    // set default page load data         
    $data['page'] = 'user/login';
    $data['form'] = 'registration';

    // set bootstrap error delimiter for registration form
    $this->form_validation->set_error_delimiters('<div class="has-danger"><small class="text-help">', '</small></div>');    

    // set validation rules for signup form fields
    $this->form_validation->set_rules('name', 'Name', 'trim|required|strip_tags|min_length[3]|max_length[100]');
	$this->form_validation->set_rules('surname', 'Surname', 'trim');
    $this->form_validation->set_rules('email', 'Email Address', 'trim|required|strip_tags|valid_email|is_unique[customers.email]');
    $this->form_validation->set_rules('username', 'Username', 'trim|required|strip_tags|callback_check_username|min_length[8]|max_length[32]|is_unique[customers.username]');
    $this->form_validation->set_rules('password', 'Password', 'trim|required|strip_tags|min_length[8]|max_length[32]');
    $this->form_validation->set_rules('confirm_password', 'Password Confirmation', 'trim|required|strip_tags|matches[password]');
    $this->form_validation->set_rules('month', 'Month', 'trim|strip_tags');
    $this->form_validation->set_rules('day', 'Day', 'trim|strip_tags');
    $this->form_validation->set_rules('year', 'Year', 'trim|strip_tags');
    $this->form_validation->set_rules('phone', 'Phone', 'trim|strip_tags');
	$this->form_validation->set_rules('gender', 'Gender', 'trim|strip_tags');
    $this->form_validation->set_rules('mobile_no', 'Mobile no', 'trim|strip_tags');
    $this->form_validation->set_rules('location', 'Location', 'trim|strip_tags');
    $this->form_validation->set_rules('accept_terms', '', 'callback_accept_terms');

    // check if site and secret key of recaptcha service exists
    $this->load->config('recaptcha');
    $site_key = $this->config->item('recaptcha_site_key');
    $secret_key = $this->config->item('recaptcha_secret_key');

    // if both keys exists validate recaptcha response
    if(($site_key) && ($secret_key)) 
    {
      $this->form_validation->set_rules('g-recaptcha-response', 'ReCaptcha Reponse', 'callback_verify_recaptcha');
    }   

    // set custom error message for unique field
    $this->form_validation->set_message('is_unique', 'The %s is already in use.');        

    // if form validation fails load signup form  
    if($this->form_validation->run() == FALSE)
    {           
      $this->load->view('index',$data);
      return false;     
    }

    // register new user
    $result = $this->user_model->register();

    // check result of operation
    switch($result)
    {
      case 0: // could not save user details into database
              $msg = 'An error occured while creating account, try again later.';
              $type = 'danger';           
              break;
          
      case 1: // account is created and activation email is sent to user
              $msg = 'Congratulations, you have successfully created your account. An activation email is sent to your email address.';
              $type = 'success';
              $data['form'] = 'login';
              break;
          
      case 2: // account is created, but could not send activation email
              $msg = 'You have successfully created your account. System could not initiate activation email.';
              $type = 'danger';
              $data['form'] = 'login';
              break;                    
          
      default:
              break;            
    }
    
    // set notification message
    $this->base->set_message($msg,$type);     
        
    redirect(site_url().'/user', 'refresh');

    return true;
  }

  /**
   * Validate username 
   *
   * @param  string  $username  username supplied by user in registration form
   * @return  boolean  TRUE if username validated, FALSE either
   */
  public function check_username($username)
  {
    // check if username started with alphabet
    if(!preg_match('/^[A-Za-z]+/', $username))
    {
      $this->form_validation->set_message('check_username', '%s should start with alphabet');
      return false;
    }
    // check if username contains valid characters
    elseif(!preg_match('/^[A-Za-z0-9_.-]+$/', $username))
    {     
      $this->form_validation->set_message('check_username', 'Only alphanumeric characters, underscores (_), dashes(-) and periods(.) are allowed');
      return false;
    }

    return true;  
  }

  /**
   * Check if user accepted the terms by clicking on checkbox 
   *
   * @param  int  $accept_terms  accept terms checkbox value
   * @return  boolean  TRUE if username validated, FALSE either
   */
  public function accept_terms($accept_terms)
  { 
    if(!$accept_terms)
    {
      $this->form_validation->set_message('accept_terms', 'Please confirm that you agree to the Terms of Service and Privacy Policy.');
      return false;
    }

    return true;
  }

  /**
   * Method to verify if user solved recaptcha successfully 
   *
   * @param  string  $response  response code received from reCAPTCHA google service
   * @return  boolean  TRUE if username validated, FALSE either
   */
  public function verify_recaptcha($response) 
  {         
    // if no response received 
    if(empty($response))
    {
      $this->form_validation->set_message('verify_recaptcha', 'Please confirm that you are not a robot.');
      return false;       
    }
    else 
    {
      // check if response code verified
      $result = $this->recaptcha->verifyResponse($response);
            
      if(!$result['success'])
      {                           
        $this->form_validation->set_message('verify_recaptcha', 'Verifying reCAPTCHA is unsuccessful. Error: '.$result['error-codes']);
        return false;       
      }
    } 

    return true;
  }   

  /**
   * Method to activate user account. This method is invoked
   * by the activation link sent to user email address on registration.
   *
   * @param  string  $key  activation key received from activation link
   */
  function activate($key)
  {
    // activate account
    $result = $this->user_model->activate_account($key);
    
    switch($result)
    {
      case 0: // If activation key not matched with any account
              $msg = 'No account is related with this activation key, either your account is already activated or key is expired !!!';  
              $type = "danger";
              break;
          
      case 1: // Account activated
              $msg = 'Congratulations, your account is activated now. Login here';
              $type = "success";          
              break;
          
      case 2: // Activation key expired
              $msg = 'Activation key expired, create new account.';
              $type = "warning";
              break;                
          
      default:
              break;
      
    }

    // set notification message to show on page
    $this->base->set_message($msg, $type);      
    
    $this->index();

    return true;
  }

  /**
   * Method to load username recovery form 
   */
  public function recover_username()
  {   
    $data['page'] = 'user/recover_username';
    $this->load->view('index',$data);
  }

  /**
   * Method to load password recovery form 
   */
  public function recover_password()
  {   
    $data['page'] = 'user/recover_password';
    $this->load->view('index',$data);
  }

  /**
   * Method to send username to email address received 
   * from user in case email address exists in database
   * to let user recover his username
   */
  public function send_username()
  {
    // set bootstrap error delimiter for registration form
    $this->form_validation->set_error_delimiters('<div class="has-error"><small class="help-block">', '</small></div>');
    $this->form_validation->set_rules('email', 'Email Address', 'trim|required|strip_tags|valid_email');    

    // if form validation fails load username recovery form 
    if($this->form_validation->run() == FALSE)
    {               
      $data['page'] = 'user/recover_username';
      $this->load->view('index',$data);
      return false;     
    } 

    // send email
    $result = (int) $this->user_model->email_username();
    
    switch($result)
    {
      case -1: // no user account found
               $msg = 'No user account is associated with supplied email address.';
               $type = 'danger';
               break;

      case 1:  // user details updated
               $msg = 'An email is sent to supplied email address containing username.';
               $type = 'success';                   
               break;

      case 0:  // could not update user details
      default: $msg = 'Could not initiate email function, try again later.';
               $type = 'danger';
               break;     
    }
    
    // set notification message
    $this->base->set_message($msg,$type);

    if($result == -1) {
      $data['page'] = 'user/recover_username';
      $this->load->view('index',$data);
    } else {
      $this->index();
    }     
  } 

  /**
   * Method to send password recovery link to user's
   * email address
   */ 
  public function get_recovery_link()
  {
    // set bootstrap error delimiter for registration form
    $this->form_validation->set_error_delimiters('<div class="has-error"><small class="help-block">', '</small></div>');
    $this->form_validation->set_rules('user', 'Email Address or Username', 'trim|required|strip_tags');   

    // if form validation fails load password recovery form 
    if($this->form_validation->run() == FALSE)
    {               
      $data['page'] = 'user/recover_password';
      $this->load->view('index',$data);
      return false;     
    } 

    // send recovery link via email
    $result = (int) $this->user_model->send_password_recovery_link();
    
    switch($result)
    {
      case -1: // no user account found
               $msg = 'No user account is associated with supplied email address/username';
               $type = 'danger';
               break;

      case 1:  // user details updated
               $msg = 'An email is sent to supplied email address containing password recovery link.';
               $type = 'success';                   
               break;

      case 0:  // could not update user details
      default: $msg = 'Could not initiate email function, try again later.';
               $type = 'danger';
               break;     
    }
    
    // set message
    $this->base->set_message($msg,$type);

    if($result == -1) 
    {
      $data['page'] = 'user/recover_password';
      $this->load->view('index',$data);
    } 
    else 
    {
      $this->index();
    }     
  } 

  /**
   * Loads reset password form page if password
   * recovery token exists in recovery link
   *
   * @param  string  $token  token supplied in password recovery link
   */
  public function reset_password($token = NULL)
  {
    if(!$token) 
    {
      $this->base->set_message('Password recovery token is missing.','danger');
      $this->index();
    } 
    else 
    {
      // add supplied token in session
      $this->session->set_userdata('token',$token);
      $data['page'] = 'user/reset_password';
      $this->load->view('index',$data);
    }   
  }

  /**
   * Method to update password received from reset
   * password form
   */
  public function update_password()
  {
    $this->form_validation->set_rules('password', 'Password', 'trim|required|strip_tags|min_length[8]|max_length[32]');

    // if form validation fails load reset password form  
    if($this->form_validation->run() == FALSE)
    {               
      $data['page'] = 'user/reset_password';
      $this->load->view('index',$data);
      return false;     
    } 

    // reset password
    $result = (int) $this->user_model->reset_password();

    switch($result)
    {
      case -2: // session expired
               $msg = 'Timeout, try again clicking on password recovery link.';
               $type = 'warning';
               break;

      case -1: // invalid token
               $msg = 'Either invalid token supplied or it is expired.';
               $type = 'danger';
               break;

      case 1:  // user details updated
               $msg = 'Reseted your password successfully.';
               $type = 'success';                   
               break;

      case 0:  // could not update user details
      default: $msg = 'An error occured while reseting your password, try again later.';
               $type = 'danger';
               break;     
    }
    
    // set message
    $this->base->set_message($msg, $type);

    $this->index();
  }
}

/* End of file User.php */
/* Location: ./application/controllers/User.php */
