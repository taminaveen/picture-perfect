<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Settings extends CI_Controller {


	function __construct()
	{
		parent::__construct();
		
		// check if user logged in 
		if (!$this->ion_auth->logged_in())
	  	{
			redirect('auth/login');
	  	}
		
		/*$groups = array('accountant', 'designer', 'viewer');
		if ($this->ion_auth->in_group($groups))
		{
			$this->session->set_flashdata('message', $this->lang->line('access_denied'));
			$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
			redirect('module=home', 'refresh');
		}*/
		
		$this->load->library('form_validation');
		$this->load->model('settings_model');


	}
	
	function system_setting()
	{
	   
	
		//validate form input
		$this->form_validation->set_message('is_natural_no_zero', $this->lang->line('no_zero_required'));
		$this->form_validation->set_rules('site_name', $this->lang->line('site_name'), 'trim|required');
		$this->form_validation->set_rules('language', $this->lang->line('language'), 'trim|required');		
		$this->form_validation->set_rules('currency_prefix', $this->lang->line('currency_code'), 'trim|required|max_length[3]');
		$this->form_validation->set_rules('date_format', $this->lang->line('date_format'), 'trim|required');
		//$this->form_validation->set_rules('barcode_symbology', $this->lang->line('barcode'), 'trim|required|xss_clean');
		$this->form_validation->set_rules('theme', $this->lang->line('theme'), 'trim|required');
		//$this->form_validation->set_rules('academic', $this->lang->line('academic'), 'required|xss_clean');
		$this->form_validation->set_rules('rows_per_page', $this->lang->line('rows_per_page'), 'trim|required|greater_than[9]|less_than[501]');
		//$this->form_validation->set_rules('school', $this->lang->line('default_school'), 'trim|required|is_natural_no_zero|xss_clean');
		//$this->form_validation->set_rules('discount_option', $this->lang->line('discount_option'), 'trim|required|xss_clean');
		$this->form_validation->set_rules('default_discount', $this->lang->line('default_discount'), 'trim|required');
		//$this->form_validation->set_rules('design_prefix', $this->lang->line('design_prefix'), 'trim|required|xss_clean');
		//$this->form_validation->set_rules('default_role', $this->lang->line('default_designation'), 'trim|required|is_natural_no_zero|xss_clean');
		//$this->form_validation->set_rules('inward_prefix', $this->lang->line('inward_prefix'), 'trim|required|xss_clean');
		//$this->form_validation->set_rules('outward_prefix', $this->lang->line('outward_prefix'), 'trim|required|xss_clean');
		//$this->form_validation->set_rules('total_rows', $this->lang->line('total_rows'), 'trim|required|greater_than[9]|less_than[100]|xss_clean');
		
		/*$this->form_validation->set_rules('warehouse', $this->lang->line('default_warehouse'), 'trim|required|is_natural_no_zero|xss_clean');
		$this->form_validation->set_rules('tax_rate', $this->lang->line('product_tax'), 'trim|required|xss_clean');
		$this->form_validation->set_rules('tax_rate2', $this->lang->line('invoice_tax'), 'trim|required|xss_clean');		
		
		$this->form_validation->set_rules('quote_prefix', $this->lang->line('quote_prefix'), 'trim|required|xss_clean');
		
		$this->form_validation->set_rules('transfer_prefix', $this->lang->line('transfer_prefix'), 'trim|required|xss_clean');		
		$this->form_validation->set_rules('product_serial', $this->lang->line('product_serial'), 'trim|required|xss_clean');
		
		$this->form_validation->set_rules('discount_method', $this->lang->line('discount_method'), 'trim|required|xss_clean');
		*/
		
		
		if ($this->form_validation->run() == true)
		{
			$language = $this->input->post('language');
			
		if((file_exists('application/language/'.$language.'/pp_lang.php') && is_dir('application/language/'.$language)) || $language == 'en'){ 
			$lang = $language;
		} else {
			$this->session->set_flashdata('message', $this->lang->line('language_x_found'));
			redirect("settings/system_setting", 'refresh');
			$lang = 'en';
		}
		
			$data = array(
				'site_name' 		=> $this->input->post('site_name'),
				'language' 			=> $lang,				
				'dateformat' 		=> $this->input->post('date_format'),
				//'default_school'	=> $this->input->post('school'),
				'currency_prefix' 	=> $this->input->post('currency_prefix'),
				//'academic_year'		=> $this->input->post('academic'),
				'theme' 			=> trim($this->input->post('theme')),
				'rows_per_page' 	=> $this->input->post('rows_per_page'),
				//'discount_option' => $this->input->post('discount_option'),
				'default_discount' => $this->input->post('default_discount'),
			);
		}
		
		if ( $this->form_validation->run() == true && $this->settings_model->updateSetting($data))
		{ 
			$this->session->set_flashdata('success_message', $this->lang->line('setting_updated'));
			redirect("settings/system_setting", 'refresh');
		}
		else
		{
			
			$data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
			$data['success_message'] = $this->session->flashdata('success_message');
			
			$data['settings'] = $this->settings_model->getSettings();
			$data['date_formats'] = $this->settings_model->getDateFormats();
			//$data['schools'] 	= $this->settings_model->getAllCompanies();
			$data['discounts'] = $this->settings_model->getAllDiscounts();
			$meta['page_title'] = $this->lang->line('system_setting');
			$data['page_title'] = $this->lang->line('system_setting');
			$this->load->view('commons/header', $meta);
			$this->load->view('settings/setting', $data);
			$this->load->view('commons/footer');
		}
	}
	
	function dimensions()
	{
		$data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
		$data['success_message'] = $this->session->flashdata('success_message');
		$data['dimentions'] 	= $this->settings_model->getAllDimensions();
		$meta['page_title'] = $this->lang->line('list_dimention');
		$data['page_title'] = $this->lang->line('list_dimention');
		$this->load->view('commons/header', $meta);
		$this->load->view('settings/dimensions', $data);
		$this->load->view('commons/footer');
	}
	
	function deliverycharges()
	{
		$data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
		$data['success_message'] = $this->session->flashdata('success_message');
		$data['shippings'] 	= $this->settings_model->getAllDeliveryCharges();
		$meta['page_title'] = $this->lang->line('list_delivery_charge');
		$data['page_title'] = $this->lang->line('list_delivery_charge');
		$this->load->view('commons/header', $meta);
		$this->load->view('settings/shipping_charges', $data);
		$this->load->view('commons/footer');
	}
	
	function create_dimension()
	{
	   //validate form input
		$this->form_validation->set_rules('dimention', $this->lang->line('dimention'), 'required');
		$this->form_validation->set_rules('printing', $this->lang->line('printing_cost'), 'required');
		$this->form_validation->set_rules('lamination', $this->lang->line('lamination_cost'), 'required');
		$this->form_validation->set_rules('framing', $this->lang->line('framing_cost'), 'required');
		
		if ( $this->form_validation->run())
		{
			$dimensionData = array(
				'name' 			=> $this->input->post('dimention'),
				'printing' 		=> $this->input->post('printing'),
				'lamination'	=> $this->input->post('lamination'),
				'framing' 		=> $this->input->post('framing'),
			);
		}
						
		if ( $this->form_validation->run() == true && $this->settings_model->addDimention($dimensionData))
		{ 
			$this->session->set_flashdata('success_message', $this->lang->line('dimension_added'));
			redirect("settings/dimensions", 'refresh');
		}
		else
		{
			
			$data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
	   
			$meta['page_title'] = $this->lang->line('add_dimention');
			$data['page_title'] = $this->lang->line('add_dimention');
			$this->load->view('commons/header', $meta);
			$this->load->view('settings/add_dimension', $data);
			$this->load->view('commons/footer');
		}
	}
   
   function edit_dimension($id = NULL)
   {
	   if($this->input->get('id')){ $id = $this->input->get('id'); }
	   //validate form input
		$this->form_validation->set_rules('dimention', $this->lang->line('dimention'), 'required');
		$this->form_validation->set_rules('printing', $this->lang->line('printing_cost'), 'required');
		$this->form_validation->set_rules('lamination', $this->lang->line('lamination_cost'), 'required');
		$this->form_validation->set_rules('framing', $this->lang->line('framing_cost'), 'required');
		
		if($this->form_validation->run())
		{
			$dimensionData = array(
				'name' 			=> $this->input->post('dimention'),
				'printing' 		=> $this->input->post('printing'),
				'lamination'	=> $this->input->post('lamination'),
				'framing' 		=> $this->input->post('framing'),
			);
		}
			
		if($this->form_validation->run() == true && $this->settings_model->updateDimention($id, $dimensionData))
		{ 
			$this->session->set_flashdata('success_message', $this->lang->line('dimension_edited'));
			redirect("settings/dimensions", 'refresh');
		}
		else
		{
	   		$data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
			
			$data['roles'] = $this->settings_model->getDimensionByID($id);
	   		$data['id']		= $id;
			$meta['page_title'] = $this->lang->line('edit_dimention');
			$data['page_title'] = $this->lang->line('edit_dimention');
			$this->load->view('commons/header', $meta);
			$this->load->view('settings/edit_dimension', $data);
			$this->load->view('commons/footer');
		}
   }
   
   function add_deliverycharge()
	{
	   //validate form input
		$this->form_validation->set_rules('weight', $this->lang->line('weight'), 'required');
		$this->form_validation->set_rules('local', $this->lang->line('local'), 'required');
		$this->form_validation->set_rules('distance1', $this->lang->line('upto200'), 'required');
		$this->form_validation->set_rules('distance2', $this->lang->line('200to1000'), 'required');
		$this->form_validation->set_rules('distance3', $this->lang->line('1001to2000'), 'required');
		$this->form_validation->set_rules('distance4', $this->lang->line('above2000'), 'required');
		
		if ( $this->form_validation->run())
		{
			$deliverychargeData = array(
				'weight' 	=> $this->input->post('weight'),
				'local' 	=> $this->input->post('local'),
				'd1'		=> $this->input->post('distance1'),
				'd2' 		=> $this->input->post('distance2'),
				'd3'		=> $this->input->post('distance3'),
				'd4' 		=> $this->input->post('distance4'),
			);
		}
						
		if($this->form_validation->run() == true && $this->settings_model->addDeliveryCharge($deliverychargeData))
		{ 
			$this->session->set_flashdata('success_message', $this->lang->line('delivery_charge_added'));
			redirect("settings/deliverycharges", 'refresh');
		}
		else
		{
			$data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
	   
			$meta['page_title'] = $this->lang->line('add_delivery_charge');
			$data['page_title'] = $this->lang->line('add_delivery_charge');
			$this->load->view('commons/header', $meta);
			$this->load->view('settings/add_shipping', $data);
			$this->load->view('commons/footer');
		}
	}
	
	function edit_deliverycharge($id = NULL)
	{
	   if($this->input->get('id')){ $id = $this->input->get('id'); }
	   //validate form input
		$this->form_validation->set_rules('weight', $this->lang->line('weight'), 'required');
		$this->form_validation->set_rules('local', $this->lang->line('local'), 'required');
		$this->form_validation->set_rules('distance1', $this->lang->line('upto200'), 'required');
		$this->form_validation->set_rules('distance2', $this->lang->line('200to1000'), 'required');
		$this->form_validation->set_rules('distance3', $this->lang->line('1001to2000'), 'required');
		$this->form_validation->set_rules('distance4', $this->lang->line('above2000'), 'required');
		
		if ( $this->form_validation->run())
		{
			$deliverychargeData = array(
				'weight' 	=> $this->input->post('weight'),
				'local' 	=> $this->input->post('local'),
				'd1'		=> $this->input->post('distance1'),
				'd2' 		=> $this->input->post('distance2'),
				'd3'		=> $this->input->post('distance3'),
				'd4' 		=> $this->input->post('distance4'),
			);
		}
			
		if($this->form_validation->run() == true && $this->settings_model->updateDeliveryCharge($id, $deliverychargeData))
		{ 
			$this->session->set_flashdata('success_message', $this->lang->line('delivery_charge_edited'));
			redirect("settings/deliverycharges", 'refresh');
		}
		else
		{
			$data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
			
			$data['shipping'] = $this->settings_model->getDeliveryChargeByID($id);
			$data['id']		= $id;
			$meta['page_title'] = $this->lang->line('edit_delivery_charge');
			$data['page_title'] = $this->lang->line('edit_delivery_charge');
			$this->load->view('commons/header', $meta);
			$this->load->view('settings/edit_shipping', $data);
			$this->load->view('commons/footer');
		}
	}
	
}