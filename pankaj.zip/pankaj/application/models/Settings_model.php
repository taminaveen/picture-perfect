<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Settings_model extends CI_Model
{
	
	
	public function __construct()
	{
		parent::__construct();

	}
	
	public function getSettings() 
	{
				
		$q = $this->db->get('settings'); 
		  if( $q->num_rows() > 0 )
		  {
			return $q->row();
		  } 
		
		  return FALSE;

	}
	
	public function getDateFormats() 
	{
		$q = $this->db->get('date_format');
		if($q->num_rows() > 0) {
			foreach (($q->result()) as $row) {
				$data[] = $row;
			}
				
			return $data;
		}
	}
	
	public function updateSetting($data)
	{

		$this->db->where('setting_id', '1');
		if($this->db->update('settings', $data)) {
			return true;
		} else {
			return false;
		}
	}
	
	public function getAllCompanies() 
	{
		$q = $this->db->get('companies');
		if($q->num_rows() > 0) {
			foreach (($q->result()) as $row) {
				$data[] = $row;
			}
				
			return $data;
		}
	}
	
	public function getAllDiscounts() 
	{
		$q = $this->db->get('discounts');
		if($q->num_rows() > 0) {
			foreach (($q->result()) as $row) {
				$data[] = $row;
			}
				
			return $data;
		}
	}
	
	public function getAllDimensions() 
	{
		$q = $this->db->get('dimensions');
		if($q->num_rows() > 0) {
			foreach (($q->result()) as $row) {
				$data[] = $row;
			}
				
			return $data;
		}
	}
	
	public function addDimention($data = array())
	{

		if($this->db->insert('dimensions', $data)) {
			return true;
		} else {
			return false;
		}
	}
	
	public function updateDimention($id, $data = array())
	{

		$this->db->where('id', $id);
		if($this->db->update('dimensions', $data)) {
			return true;
		} else {
			return false;
		}
	}
	
	public function getDimensionByID($id) 
	{

		$q = $this->db->get_where('dimensions', array('id' => $id), 1); 
		  if( $q->num_rows() > 0 )
		  {
			return $q->row();
		  } 
		
		  return FALSE;

	}
	
	
	public function getAllDeliveryCharges() 
	{
		$q = $this->db->get('deliveryfees');
		if($q->num_rows() > 0) {
			foreach (($q->result()) as $row) {
				$data[] = $row;
			}
				
			return $data;
		}
	}
	
	public function addDeliveryCharge($data = array())
	{
		if($this->db->insert('deliveryfees', $data)) {
			return true;
		} else {
			return false;
		}
	}
	
	public function updateDeliveryCharge($id, $data = array())
	{
		$this->db->where('id', $id);
		if($this->db->update('deliveryfees', $data)) {
			return true;
		} else {
			return false;
		}
	}
	
	public function getDeliveryChargeByID($id) 
	{
		$q = $this->db->get_where('deliveryfees', array('id' => $id), 1); 
		  if( $q->num_rows() > 0 )
		  {
			return $q->row();
		  } 
		
		  return FALSE;

	}
	
}