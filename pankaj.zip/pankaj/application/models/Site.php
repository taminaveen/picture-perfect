<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Site extends CI_Model
{

    public function __construct() {
        parent::__construct();
    }
	
	public function getAllPrintOrders() 
	{
		$q = $this->db->get('printing_orders');
		if($q->num_rows() > 0) {
			foreach (($q->result()) as $row) {
				$data[] = $row;
			}
				
			return $data;
		}
	}
	
	public function getAllCustomerAddresses($cuid) 
	{
		$q = $this->db->get_where('customer_addresses', array('customer_id' => $cuid));
		if($q->num_rows() > 0) {
			foreach (($q->result()) as $row) {
				$data[] = $row;
			}
				
			return $data;
		}
	}
	
	public function updateOrderStatus($id, $data = array())
    {
        $this->db->where('id', $id);
        if ($this->db->update('printing_orders', $data)) {
            return true;
        }
        return false;
    }
	
	public function modal_js() {
        return '<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>';
    }
	
	public function getAllDimesions() 
	{
		$q = $this->db->get('dimensions');
		if($q->num_rows() > 0) {
			foreach (($q->result()) as $row) {
				$data[] = $row;
			}
				
			return $data;
		}
	}
	
	public function getDimensionByID($id) 
	{

		$q = $this->db->get_where('dimensions', array('id' => $id), 1); 
		  if( $q->num_rows() > 0 )
		  {
			return $q->row();
		  } 
		
		  return FALSE;

	}
	
	public function getAllDeliverycharges() 
	{
		$q = $this->db->get('deliveryfees');
		if($q->num_rows() > 0) {
			foreach (($q->result()) as $row) {
				$data[] = $row;
			}
				
			return $data;
		}
	}
	
}