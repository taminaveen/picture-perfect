<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <meta charset="utf-8" />
   <title><?=SITE_NAME?> :: <?=$page_title?></title>
   <meta content="width=device-width, initial-scale=1.0" name="viewport" />
   <meta content="" name="description" />
   <meta content="Mosaddek" name="author" />
   <link href="<?php echo base_url(); ?>theme/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>theme/assets/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>theme/assets/bootstrap/css/bootstrap-fileupload.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>theme/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>theme/css/btn.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>theme/css/style.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>theme/css/style-responsive.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>theme/css/style-<?=THEME?>.css" rel="stylesheet" id="style_color" />
   <link href="<?php echo base_url(); ?>theme/assets/fancybox/source/jquery.fancybox.css" rel="stylesheet" />
   <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>theme/assets/chosen-bootstrap/chosen/chosen.css" />
   <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>theme/assets/uniform/css/uniform.default.css" />
   <link href="<?php echo base_url(); ?>theme/assets/data-tables/dataTables.tableTools.css" rel="stylesheet" />
   <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
   <script src="<?php echo base_url(); ?>theme/js/jquery-1.8.3.min.js"></script>
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="fixed-top">
   <!-- BEGIN HEADER -->
   <div id="header" class="navbar navbar-inverse navbar-fixed-top">
       <!-- BEGIN TOP NAVIGATION BAR -->
       <div class="navbar-inner">
           <div class="container-fluid">
               <!--BEGIN SIDEBAR TOGGLE-->
               <div class="sidebar-toggle-box hidden-phone">
                   <div class="icon-reorder tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
               </div>
               <!--END SIDEBAR TOGGLE-->
               <!-- BEGIN LOGO -->
               <a class="brand" href="index.html">
                   <img src="<?php echo base_url(); ?>theme/img/logo.png" alt="Metro Lab" />
               </a>
               <!-- END LOGO -->
               <!-- BEGIN RESPONSIVE MENU TOGGLER -->
               <a class="btn btn-navbar collapsed" id="main_menu_trigger" data-toggle="collapse" data-target=".nav-collapse">
                   <span class="icon-bar"></span>
                   <span class="icon-bar"></span>
                   <span class="icon-bar"></span>
                   <span class="arrow"></span>
               </a>
               <!-- END RESPONSIVE MENU TOGGLER -->
               
               <!-- END  NOTIFICATION -->
               <div class="top-nav ">
                   <ul class="nav pull-right top-menu" >
                      <!-- BEGIN USER LOGIN DROPDOWN -->
                       <li class="dropdown">
                           <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                               <img src="<?php echo base_url(); ?>theme/img/avatar1_small.jpg" alt="">
                               <span class="username"><?=USER_NAME?></span>
                               <b class="caret"></b>
                           </a>
                           <ul class="dropdown-menu extended logout">
                               <li><a href="<?php echo site_url('auth/my_profile/'.USER_ID); ?>"><i class="icon-user"></i> My Profile</a></li>
                               <!--<li><a href="#"><i class="icon-cog"></i> My Settings</a></li>-->
                               <li><a href="<?php echo site_url('auth/logout'); ?>"><i class="icon-signout"></i> Log Out</a></li>
                           </ul>
                       </li>
                       <!-- END USER LOGIN DROPDOWN -->
                   </ul>
                   <!-- END TOP NAVIGATION MENU -->
               </div>
           </div>
       </div>
       <!-- END TOP NAVIGATION BAR -->
   </div>
   <?php
		$method = $this->router->fetch_method();
   ?>
   <!-- END HEADER -->
   <!-- BEGIN CONTAINER -->
   <div id="container" class="row-fluid">
      <!-- BEGIN SIDEBAR -->
      <div class="sidebar-scroll">
        <div id="sidebar" class="nav-collapse collapse">

         <!-- BEGIN RESPONSIVE QUICK SEARCH FORM -->
        <!-- <div class="navbar-inverse">
            <form class="navbar-search visible-phone">
               <input type="text" class="search-query" placeholder="Search" />
            </form>
         </div>-->
         <!-- END RESPONSIVE QUICK SEARCH FORM -->
         <!-- BEGIN SIDEBAR MENU -->
          <ul class="sidebar-menu">
              <li class="sub-menu <?php echo activate_menu('welcome'); ?>">
                  <a class="" href="<?php echo site_url('welcome'); ?>">
                      <i class="icon-dashboard"></i>
                      <span>Dashboard</span>
                  </a>
              </li>
              
              <li class="sub-menu <?php echo activate_menu('auth'); ?>">
                  <a href="javascript:;" class="">
                      <i class="icon-male"></i>
                      <span>Users</span>
                      <span class="arrow"></span>
                  </a>
                  <ul class="sub">
                      <li class="<?php if($method == "users") { echo 'active'; } ?>"><a href="<?php echo site_url('auth/users'); ?>"><i class="icon-list"></i> List Users</a></li>
                      <li class="<?php if($method == "create_user") { echo 'active'; } ?>"><a href="<?php echo site_url('auth/create_user'); ?>"><i class="icon-plus-sign"></i> Add User</a></li>
                      <li class="<?php if($method == "users") { echo 'active'; } ?>"><a href="<?php echo site_url('auth/groups'); ?>"><i class="icon-list"></i>List User Groups</a></li>
                      <li class="<?php if($method == "create_group") { echo 'active'; } ?>"><a href="<?php echo site_url('auth/create_group'); ?>"><i class="icon-plus-sign"></i> Add User Group</a></li>
                  </ul>
              </li>
              
              <li class="sub-menu <?php echo activate_menu('user'); ?>">
                  <a class="" href="<?php echo site_url('user/customers'); ?>">
                      <i class="icon-group"></i>
                      <span>Customers</span>
                  </a>
              </li>  
                          
              <li class="sub-menu <?php echo activate_menu('orders'); ?>">
                  <a href="<?php echo site_url('orders/index'); ?>" class="">
                      <i class="icon-tasks"></i>
                      <span>Orders</span>
                  </a>
              </li>
              
              <li class="sub-menu">
                  <a class="" href="javascript:;">
                      <i class="icon-money"></i>
                      <span>Payments</span>
                      <span class="arrow"></span>
                  </a>
                  <ul class="sub">
                  	<li><a href="https://www.moneybookers.com/app/payment.pl">Pay by Stripe</a></li>
                 </ul>
              </li>
              
              <li class="sub-menu <?php echo activate_menu('settings'); ?>">
                  <a class="" href="javascript:;">
                      <i class="icon-cogs"></i>
                      <span>Settings</span>
                      <span class="arrow"></span>
                  </a>
                  <ul class="sub">
                  		<li class="<?php if($method == "system_setting") { echo 'active'; } ?>"><a href="<?php echo site_url('settings/system_setting'); ?>"><i class="icon-wrench"></i> <?php echo lang('system_setting');?></a></li>
                      	<li class="<?php if($method == "dimensions" || $method == "add_dimension" || $method == "edit_dimension") { echo 'active'; } ?>"><a href="<?php echo site_url('settings/dimensions'); ?>"><i class="icon-anchor"></i> <?php echo lang('dimentions');?></a></li>
                      <li class="<?php if($method == "deliverycharges" || $method == "add_deliverycharge" || $method == "edit_deliverycharge") { echo 'active'; } ?>"><a href="<?php echo site_url('settings/deliverycharges'); ?>"><i class="icon-search"></i><?php echo lang('delivery_charges');?></a></li>
                      <li><a href="<?php echo site_url().'admin/media'; ?>"><i class="icon-film"></i> <?php echo lang('media_settings');?></a></li>
                  </ul>
              </li>
              
              <li class="sub-menu">
                  <a class="" href="javascript:;">
                      <i class="icon-bar-chart"></i>
                      <span>Reports</span>
                      <span class="arrow"></span>
                  </a>
                  <ul class="sub">
                  </ul>
              </li>
          </ul>
         <!-- END SIDEBAR MENU -->
      </div>
      </div>