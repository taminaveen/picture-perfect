	</div>
   <!-- END CONTAINER -->
   
   <!-- BEGIN FOOTER -->
   <div id="footer">
       <?=date("Y")?> &copy; AARUSH INFOTECH PRIVATE LIMITED.
   </div>
   <!-- END FOOTER -->

   <!-- BEGIN JAVASCRIPTS -->
   <!-- Load javascripts at bottom, this will reduce page load time -->
   
   <script src="<?php echo base_url(); ?>theme/js/jquery.nicescroll.js" type="text/javascript"></script>
   <script src="<?php echo base_url(); ?>theme/assets/bootstrap/js/bootstrap.min.js"></script>
   <script src="<?php echo base_url(); ?>theme/js/jquery.blockui.js"></script>
   <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
   <!-- ie8 fixes -->
   <!--[if lt IE 9]>
   <script src="js/excanvas.js"></script>
   <script src="js/respond.js"></script>
   <![endif]-->
   <script type="text/javascript" src="<?php echo base_url(); ?>theme/js/jquery.validate.min.js"></script>
   <script type="text/javascript" src="<?php echo base_url(); ?>theme/js/additional-methods.min.js"></script>
   <script type="text/javascript" src="<?php echo base_url(); ?>theme/assets/chosen-bootstrap/chosen/chosen.jquery.min.js"></script>
   <script type="text/javascript" src="<?php echo base_url(); ?>theme/assets/uniform/jquery.uniform.min.js"></script>
   <script type="text/javascript" src="<?php echo base_url(); ?>theme/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php echo base_url(); ?>theme/assets/data-tables/dataTables.tableTools.js"></script>
   <script type="text/javascript" src="<?php echo base_url(); ?>theme/assets/data-tables/jquery.dataTables.columnFilter.js"></script>
   <script type="text/javascript" src="<?php echo base_url(); ?>theme/assets/data-tables/DT_bootstrap.js"></script>
   <script src="<?php echo base_url(); ?>theme/js/jquery.scrollTo.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>theme/assets/gritter/js/jquery.gritter.js"></script>

   <!--common script for all pages-->
   <script src="<?php echo base_url(); ?>theme/js/gritter.js" type="text/javascript"></script>
   <script src="<?php echo base_url(); ?>theme/js/dt-functions.js"></script>
   <script src="<?php echo base_url(); ?>theme/js/common-scripts.js"></script>
   <script src="<?php echo base_url(); ?>theme/js/form-component.js"></script>
   
   <!-- END JAVASCRIPTS -->   
</body>
<!-- END BODY -->
</html>