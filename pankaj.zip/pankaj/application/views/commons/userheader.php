<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <meta charset="utf-8" />
   <title><?=$page_title?></title>
   <meta content="width=device-width, initial-scale=1.0" name="viewport" />
   <meta content="" name="description" />
   <meta content="Mosaddek" name="author" />
   <link href="<?php echo base_url(); ?>theme/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>theme/assets/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>theme/assets/bootstrap/css/bootstrap-fileupload.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>theme/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>theme/css/btn.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>theme/css/style.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>theme/css/style-responsive.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>theme/css/style-default.css" rel="stylesheet" id="style_color" />
   <link href="<?php echo base_url(); ?>theme/assets/fancybox/source/jquery.fancybox.css" rel="stylesheet" />
   <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>theme/assets/chosen-bootstrap/chosen/chosen.css" />
   <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>theme/assets/uniform/css/uniform.default.css" />
   <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/jquery-tags-input/jquery.tagsinput.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/clockface/css/clockface.css" />
   <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>theme/assets/bootstrap-datepicker/css/datepicker.css" />
   <link href="<?php echo base_url(); ?>theme/assets/data-tables/dataTables.tableTools.css" rel="stylesheet" />
   <link href="http://code.jquery.com/ui/1.8.24/themes/blitzer/jquery-ui.css" rel="stylesheet" type="text/css" />
   <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="fixed-top">
   <!-- BEGIN HEADER -->
   <div id="header" class="navbar navbar-inverse navbar-fixed-top">
       <!-- BEGIN TOP NAVIGATION BAR -->
       <div class="navbar-inner">
           <div class="container-fluid">
               <!--BEGIN SIDEBAR TOGGLE-->
               <div class="sidebar-toggle-box hidden-phone">
                   <div class="icon-reorder tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
               </div>
               <!--END SIDEBAR TOGGLE-->
               <!-- BEGIN LOGO -->
               <a class="brand" href="<?php echo base_url('user/index/'); ?>">
                   <img src="<?php echo base_url(); ?>theme/img/logo.png" alt="Metro Lab" />
               </a>
               <!-- END LOGO -->
               <!-- BEGIN RESPONSIVE MENU TOGGLER -->
               <a class="btn btn-navbar collapsed" id="main_menu_trigger" data-toggle="collapse" data-target=".nav-collapse">
                   <span class="icon-bar"></span>
                   <span class="icon-bar"></span>
                   <span class="icon-bar"></span>
                   <span class="arrow"></span>
               </a>
               <!-- END RESPONSIVE MENU TOGGLER -->
               
               <!-- END  NOTIFICATION -->
               <div class="top-nav ">
                   <ul class="nav pull-right top-menu" >
                      <!-- BEGIN USER LOGIN DROPDOWN -->
                       <li class="dropdown">
                           <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <?php if(USER_IMAGE == NULL || USER_IMAGE == ''){?>
                                 <img src="<?php echo base_url(); ?>theme/img/avatar1_small.jpg" alt="">
                             <?php } else { ?>
                                 <img alt="" src="<?php echo base_url(); ?>theme/uploads/thumbs/<?=USER_IMAGE?>">
                             <?php } ?>                               
                               <span class="username"><?=@USER_NAME?></span>
                               <b class="caret"></b>
                           </a>
                           <ul class="dropdown-menu extended logout">
                               <li><a href="<?php echo site_url('user/my_profile/'.USER_ID); ?>"><i class="icon-user"></i> My Profile</a></li>
                               <li><a href="<?php echo site_url('user/change_password/'); ?>"><i class="icon-key"></i> Change Password</a></li>
                               <li><a href="<?php echo site_url('user/change_picture/'.USER_ID); ?>"><i class="icon-cog"></i> My Settings</a></li>
                               <li><a href="<?php echo site_url('user/logout'); ?>"><i class="icon-signout"></i> Log Out</a></li>
                           </ul>
                       </li>
                       <!-- END USER LOGIN DROPDOWN -->
                   </ul>
                   <!-- END TOP NAVIGATION MENU -->
               </div>
           </div>
       </div>
       <!-- END TOP NAVIGATION BAR -->
   </div>
   <?php
		$method = $this->router->fetch_method();
   ?>
   <!-- END HEADER -->
   <!-- BEGIN CONTAINER -->
   <div id="container" class="row-fluid">
      <!-- BEGIN SIDEBAR -->
      <div class="sidebar-scroll">
        <div id="sidebar" class="nav-collapse collapse">

         <!-- BEGIN RESPONSIVE QUICK SEARCH FORM -->
        <!-- <div class="navbar-inverse">
            <form class="navbar-search visible-phone">
               <input type="text" class="search-query" placeholder="Search" />
            </form>
         </div>-->
         <!-- END RESPONSIVE QUICK SEARCH FORM -->
         <!-- BEGIN SIDEBAR MENU -->
          <ul class="sidebar-menu">
              <li class="sub-menu <?php if($method == "index") { echo activate_menu('user'); } ?>">
                  <a class="" href="<?php echo site_url('user'); ?>">
                      <i class="icon-dashboard"></i>
                      <span>Dashboard</span>
                  </a>
              </li>
              
              <li class="sub-menu <?php if($method == "orders" || $method == "add_order" || $method == "edit_order") { echo activate_menu('user'); } ?>">
                  <a href="javascript:;" class="">
                      <i class="icon-tasks"></i>
                      <span>Orders</span>
                      <span class="arrow"></span>
                  </a>
                  <ul class="sub">
                  	<li class="<?php if($method == "orders") { echo 'active'; } ?>"><a href="<?php echo site_url('user/orders'); ?>"><i class="icon-wrench"></i> My Orders</a></li>
                      	<li class="<?php if($method == "add_order" || $method == "edit_order") { echo 'active'; } ?>"><a href="<?php echo site_url('user/add_order'); ?>"><i class="icon-anchor"></i> New Order</a></li>
                  </ul>
              </li>
              
               <li class="sub-menu">
                  <a class="" href="<?php echo site_url('media/index'); ?>">
                      <i class="icon-film"></i>
                      <span>File Manager</span>
                  </a>
              </li>
          </ul>
         <!-- END SIDEBAR MENU -->
      </div>
      </div>