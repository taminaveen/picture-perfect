<script>
$(function(){
	$("#form1").validate({
		rules: {
                group_name: "required",
                description: {
                    required: true,
                },               
                
            },
            messages: {
                group_name: "Please enter group name",                
                description: "Please enter group description",                              
            }	
	});
});
</script>
<div id="main-content">
         <!-- BEGIN PAGE CONTAINER-->
     <div class="container-fluid">
        <!-- BEGIN PAGE HEADER-->   
        <div class="row-fluid">
           <div class="span12">
            	<?php if($message) { echo "<div class=\"alert alert-danger\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>
           </div>
        </div>

		<div class="row-fluid">
            <div class="span12">
            <!-- BEGIN EXAMPLE TABLE widget-->
            <div class="widget red">
                <div class="widget-title">
                    <h4><i class="icon-plus-sign-alt"></i><?php echo $page_title; ?></h4>
                        <span class="tools">
                            <a href="javascript:;" class="icon-chevron-down"></a>
                            <a href="javascript:;" class="icon-remove"></a>
                        </span>
                </div>
                <div class="widget-body">
                <?php echo form_open("auth/create_group",'class="form-horizontal" id="form1" ');?>
                
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('create_group_name_label', 'group_name');?></label>
                        <div class="controls">
                            <?php echo form_input($group_name);?>
                        </div>
                    </div>
                    
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('create_group_desc_label', 'description');?></label>
                        <div class="controls">
                            <?php echo form_input($description);?>
                        </div>
                    </div>
                    
                    
                    <div class="form-actions">
                        <?php echo form_submit('submit', lang('create_group_submit_btn'),'class="btn btn-primary"');?>
                    </div>
                    <?php echo form_close();?>
                </div>
            </div>
            <!-- END EXAMPLE TABLE widget-->
            </div>
		</div>
    </div>
</div>