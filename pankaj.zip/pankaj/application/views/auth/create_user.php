<div id="main-content">
         <!-- BEGIN PAGE CONTAINER-->
     <div class="container-fluid">
        <!-- BEGIN PAGE HEADER-->   
        <div class="row-fluid">
           <div class="span12">
            	<?php if($message) { echo "<div class=\"alert alert-danger\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>
           </div>
        </div>
        <!-- END PAGE HEADER-->
        <!-- BEGIN ADVANCED TABLE widget-->
        <div class="row-fluid">
            <div class="span12">
            <!-- BEGIN EXAMPLE TABLE widget-->
            <div class="widget green">
                <div class="widget-title">
                    <h4><i class="icon-plus-sign-alt"></i><?php echo $page_title; ?></h4>
                        <span class="tools">
                            <a href="javascript:;" class="icon-chevron-down"></a>
                            <a href="javascript:;" class="icon-remove"></a>
                        </span>
                </div>
                <div class="widget-body">
                <?php echo form_open("auth/create_user",'class="form-horizontal" id="signupForm" ');?>
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('create_user_fname_label', 'first_name');?></label>
                        <div class="controls">
                            <?php echo form_input($first_name);?>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('create_user_lname_label', 'last_name');?></label>
                        <div class="controls">
                            <?php echo form_input($last_name);?>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('create_user_company_label', 'company');?></label>
                        <div class="controls">
                            <?php echo form_input($company);?>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('create_user_email_label', 'email');?></label>
                        <div class="controls">
                            <?php echo form_input($email);?>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('create_user_phone_label', 'phone');?> </label>
                        <div class="controls">
                            <?php echo form_input($phone);?>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">User Role</label>
                          <div class="controls">
                              <select name="role" id="role" class="form-control" required>
                                <option value="">----Select User Role----</option>
                                <?php 
                                    foreach($groups as $group){
                                         if($group->id != 1){
                                ?>
                                <option value="<?=$group->id?>"><?=$group->description?></option>
                                <?php }} ?>
                            </select>
                          </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('create_user_password_label', 'password');?></label>
                        <div class="controls">
                            <?php echo form_input($password);?>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('create_user_password_confirm_label', 'password_confirm');?></label>
                        <div class="controls">
                            <?php echo form_input($password_confirm);?>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label"></label>
                        <div class="controls">
                            <?php echo form_submit('submit', lang('create_user_submit_btn'),'class="btn btn-success"');?>
                        </div>
                    </div>
                    <?php echo form_close();?>
                </div>
            </div>
            <!-- END EXAMPLE TABLE widget-->
            </div>
        </div>

        <!-- END ADVANCED TABLE widget-->
     </div>
         <!-- END PAGE CONTAINER-->
      </div>
