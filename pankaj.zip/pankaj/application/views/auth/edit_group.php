<div id="main-content">
         <!-- BEGIN PAGE CONTAINER-->
     <div class="container-fluid">
        <!-- BEGIN PAGE HEADER-->   
        <div class="row-fluid">
           <div class="span12">
            	<?php if($message) { echo "<div class=\"alert alert-danger\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>
           </div>
        </div>
        <!-- END PAGE HEADER-->
        <!-- BEGIN ADVANCED TABLE widget-->
        <div class="row-fluid">
            <div class="span12">
            <!-- BEGIN EXAMPLE TABLE widget-->
            <div class="widget yellow">
                <div class="widget-title">
                    <h4><i class="icon-edit"></i><?php echo $page_title; ?></h4>
                        <span class="tools">
                            <a href="javascript:;" class="icon-chevron-down"></a>
                            <a href="javascript:;" class="icon-remove"></a>
                        </span>
                </div>
                <div class="widget-body">
					<?php echo form_open(current_url(),'class="form-horizontal" id="form1" ');?>
                    
                        <div class="control-group">
                            <label class="control-label"><?php echo lang('edit_group_name_label', 'group_name');?></label>
                            <div class="controls">
                                <?php echo form_input($group_name);?>
                            </div>
                        </div>
                        
                        <div class="control-group">
                            <label class="control-label"> <?php echo lang('edit_group_desc_label', 'description');?></label>
                            <div class="controls">
                                <?php echo form_input($group_description);?>
                            </div>
                        </div>
    
                        <div class="form-actions">
                            <?php echo form_submit('submit', lang('edit_group_submit_btn'),'class="btn btn-primary"');?>
                        </div>

					<?php echo form_close();?>
				  </div>
        	   </div>
               
           </div>
		</div>
    </div>
</div>