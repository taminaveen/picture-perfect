	<!-- Full Navigation wrapper -->
	<div class="top-nav-full">




		<!-- Menu holder -->
		<div id="sticky-holder">
			<!-- Menu not-visible holder / -->
		    <div id="not-sticky" class="sticky-default"></div>
		    <!-- Menu visible -->
			<section id="sticky" class="sticky-default">
				<!-- Container -->



					<!-- Your logo -->
					<div class="small-logo opacity-zero">
						<h1><span class="bold">PICTURE</span>PERFECT</h1>
					</div>
					<!-- [end] Your logo -->






					<!-- Main Menu -->
					<nav class="main-menu">
					<ul id="top-menu" class="jetmenu">

						<!-- Menu Item -->
						<li class="active blue"><a href="<?php echo base_url(); ?>"><i class="fa fa-home"></i><div class="menu-text"><h3>Home</h3></div></a></li>
						<!-- end Menu item -->

						<!-- Menu Item -->
						<li class="red"><a href="javascript:;"><i class="fa fa-building-o"></i><div class="menu-text"><h3>About Us</h3></div></a></li>
						<!-- end Menu item -->

						<!-- Menu Item -->
						<li class="green"><a href="javascript:;"><i class="fa fa-camera"></i><div class="menu-text"><h3>Services</h3></div></a></li>
						<!-- end Menu item -->

						<!-- Menu Item -->
						<li class="purple"><a href="javascript:;"><i class="fa fa-film"></i><div class="menu-text"><h3>Gallery</h3></div></a></li>
						<!-- end Menu item -->

						<!-- Menu Item -->
						<li class="blue"><a href="javascript:;"><i class="fa fa-phone"></i><div class="menu-text"><h3>Contact Us</h3></div></a></li>
						<!-- end Menu item -->

						<!-- Menu Item -->
						<li class="dark"><a href="javascript:;"><i class="fa fa-sign-in"></i><div class="menu-text"><h3>Sign In</h3></div></a></li>
						<!-- end Menu item -->
                        
						<!--<li class="dark"><a href="page_typography.html"><i class="fa fa-pencil"></i><div class="menu-text"><h3>Typography</h3><h4>and more...</h4></div></a></li>-->
					</ul>
					</nav>
					<!-- [end] Main Menu -->
					<!-- [end] Container -->

			</section>
			<!-- [end] Menu visible -->
		</div>
		<!-- [end] Menu holder -->
	</div>
	<!-- [end] Full Navigation wrapper -->
</div>