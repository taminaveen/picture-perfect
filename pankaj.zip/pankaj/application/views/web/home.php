<?php
include("slider.php");
include("menu.php");
?>
<section class="services clearfix header-scroll-link">

<div class="container">

	<a id="about"></a>

	<div class="typed-wrapper">
		<ul class="typed-elements">
			<li>Hello!</li>
			<li>We have something to share...</li>
			<li>Something you'll love...</li>
			<li>Say hello to Picture Perfect</li>
		</ul>

		<h1 class="large typed-export">&nbsp;</h1>
	</div>

	<h2 class="large">Thanks for becoming a member and giving us an opportunity to serve you. At present, we wish to offer a bouquet of services for photograph printing, lamination and framing services to our members and aspire to create a Collaboration Platform as we move forward to offer many more services on our enhanced platform.</h2>
</div>

<div class="container">

	<ul>

		<!-- Service card -->
		<li>
			<section class="one-third column service-card opacity-zero translate-default-down">

				<div class="colored">

					<div class="service-top-part service1">
					<div class="overlay blue"></div>

						<div class="icon-wrapper">
							<i class="fa fa-picture-o"></i>
						</div>
					<h1>Photo Printing</h1>
					</div>


				<div class="service-desc"><p>With the advent of digital photography in last couple of years, it has become very easy to click photographs while being on a vacation, family functions, get together, road trips and even office functions, ending up with loads of photographs on multiple digital medias like pen drive, laptop, smartphones etc.
				</p>
					<div class="gradient-white"></div>
				</div>



				<ul>
					<li><i class="fa fa-check-circle color-ok"></i>Pixel Perfect Print Quality<hr></li>
					<li><i class="fa fa-check-circle color-ok"></i>"Close to Heart" and "Special Moments"<hr></li>
					<li><i class="fa fa-check-circle color-ok"></i>Photo printing, lamination and framing</li>
				</ul>
				</div>

			</section>
		</li>
		<!-- [end] Service card -->

		<!-- Service card -->
		<li>
			<section class="one-third column service-card opacity-zero translate-default-down">

				<div class="colored">
					<div class="service-top-part service2">
					<div class="overlay red"></div>

					<div class="icon-wrapper">
						<i class="fa fa-lightbulb-o"></i>
					</div>
					<h1>Lamination</h1>
					</div>

				<div class="service-desc"><p>Lamination is the technique of manufacturing a material in multiple layers, so that the composite material achieves improved strength, stability, sound insulation, appearance or other properties from the use of differing materials.
				</p>
					<div class="gradient-white"></div>
				</div>


				<ul>
					<li><i class="fa fa-check-circle color-ok"></i>Pixel Perfect Print Quality<hr></li>
					<li><i class="fa fa-check-circle color-ok"></i>"Close to Heart" and "Special Moments"<hr></li>
					<li><i class="fa fa-check-circle color-ok"></i>Photo printing, lamination and framing </li>
				</ul>
				</div>

			</section>
		</li>
		<!-- [end] Service card -->

		<!-- Service card -->
		<li>
			<section class="one-third column service-card opacity-zero translate-default-down">


				<div class="colored">
					<div class="service-top-part service3">
						<div class="overlay green"></div>

					<div class="icon-wrapper">
						<i class="fa fa-pencil"></i>
					</div>
					<h1>Framing</h1>
					</div>

				<div class="service-desc"><p>A picture frame is a decorative edging for a picture, such as a painting or photograph, intended to enhance it, make it easier to display or protect it.
				</p>
					<div class="gradient-white"></div>
				</div>


				<ul>
					<li><i class="fa fa-check-circle color-ok"></i>Pixel Perfect Print Quality<hr></li>
					<li><i class="fa fa-check-circle color-ok"></i>"Close to Heart" and "Special Moments"<hr></li>
					<li><i class="fa fa-check-circle color-ok"></i>Photo printing, lamination and framing</li>
				</ul>
				</div>
			</section>
		</li>
		<!-- [end] Service card -->

	</ul>

</div>



</section>