<!--  =====================  -->
<!--  = Slider Revolution =  -->
<!--  =====================  -->
<div class="bannercontainer">
	<div class="banner">

		<ul>

<!-- Slide #1 -->
		 <li data-transition="zoomout" data-slotamount="4" data-masterspeed="3000" data-delay="11000">
		   <img src="<?php echo base_url(); ?>front/images/placeholders/grass_fence.jpg" data-bgrepeat="no-repeat" data-bgfit="cover" data-bgposition="center center" alt="bg image">


		   <div class="caption sfb small-tagline"  data-x="center" data-y="center" data-voffset="-40" data-speed="500" data-start="2600" data-end="6600" data-easing="easeOutBack"><h2>We wanted to create something</h2></div>

		   <div class="caption sfb big-tagline"  data-x="center" data-y="center" data-voffset="0" data-speed="500" data-start="3000" data-end="6300" data-easing="easeOutBack"><h1>Remarkable</h1></div>

		   <div class="caption sft under-dots stt" data-x="center" data-y="center" data-voffset="50" data-hoffset="-120" data-speed="400" data-start="4000" data-end="6500" data-easing="easeOutBack"><h2>print your</h2></div>

		   <div class="caption sft under-dots stt" data-x="center" data-y="center" data-voffset="45" data-hoffset="-75" data-speed="400" data-start="4000" data-end="6500" data-easing="easeOutBack"><div class="dot"></div></div>

		   <div class="caption sft under-dots stt" data-x="center" data-y="center" data-voffset="50" data-speed="400" data-start="4000" data-end="6500" data-easing="easeOutBack"><h2>Memorable Moments</h2></div>

		  <!-- <div class="caption sft under-dots stt" data-x="center" data-y="center" data-voffset="45" data-hoffset="56" data-speed="400" data-start="4000" data-end="6500" data-easing="easeOutBack"><div class="dot"></div></div>-->

		   <!--<div class="caption sft under-dots stt" data-x="center" data-y="center" data-voffset="50" data-hoffset="110" data-speed="400" data-start="4000" data-end="6500" data-easing="easeOutBack"><h2></h2></div>-->

		   <div class="caption sfb small-tagline"  data-x="center" data-y="center" data-voffset="-90" data-speed="500" data-start="7000" data-easing="easeOutBack"><h2>Picture Perfect Quality</h2></div>

		   <div class="caption sfb big-tagline"  data-x="center" data-y="center" data-voffset="-50" data-speed="500" data-start="7400" data-easing="easeOutBack"><h1>Combine your own</h1></div>

		    <div class="caption sfb small-caption"  data-x="center" data-y="center" data-voffset="-8" data-speed="500" data-start="7600" data-easing="easeOutBack"><h3>Close to Heart</h3></div>

		    <div class="caption sfb small-caption mobile-hide"  data-x="center" data-y="center" data-voffset="30" data-speed="500" data-start="8600" data-easing="easeOutBack"><h3>Special Moments</h3></div>

		    <div class="caption sfb small-caption mobile-hide"  data-x="center" data-y="center" data-voffset="65" data-speed="500" data-start="9100" data-easing="easeOutBack"><h3>photograph printing </h3></div>

		    <div class="caption sfb small-caption mobile-hide"  data-x="center" data-y="center" data-voffset="100" data-speed="500" data-start="9600" data-easing="easeOutBack"><h3> lamination and framing</h3></div>

		    <div class="caption sfb small-caption mobile-hide"  data-x="center" data-y="center" data-voffset="135" data-speed="500" data-start="10100" data-easing="easeOutBack"><h3>... & many more</h3></div>

		 </li>



<!-- Slide #2 -->
		<li data-transition="zoomout" data-slotamount="4" data-masterspeed="3000" data-delay="15000" >
		   <img src="<?php echo base_url(); ?>front/images/placeholders/canon_clip.jpg" data-bgrepeat="no-repeat" data-bgfit="cover" data-bgposition="center center" alt="bg image">


		   <div class="caption sfb small-tagline"  data-x="center" data-y="center" data-voffset="-40" data-speed="500" data-start="1600" data-easing="easeOutBack"><h2>Pixel perfect, hand-crafted</h2></div>

		   <div class="caption sfb big-tagline"  data-x="center" data-y="center" data-voffset="0" data-speed="500" data-start="2000" data-easing="easeOutBack"><h1>Print Your Beautiful Memories</h1></div>

		   <a href="javascript:;" class="caption sft header-button blue" data-x="center" data-y="center" data-voffset="70" data-speed="1500" data-start="2500" data-easing="easeOutBack"><i class="fa fa-star-o"></i>Start Here</a>

		    <div class="caption sfb big-caption mobile-hide"  data-x="right" data-y="center" data-speed="500" data-voffset="-120" data-start="3200" data-easing="easeOutBack"><h3>Picture Perfect <span class="bold">wish to offer a bouquet of services </span></h3></div>

		    <div class="caption sfb small-caption mobile-hide"  data-x="right" data-y="center" data-speed="500" data-voffset="-70" data-start="3600" data-easing="easeOutBack"><h3>Hassle free printing and delivery services</h3></div>

		    <div class="caption sfb small-caption mobile-hide"  data-x="right" data-y="center" data-speed="500" data-voffset="-30" data-start="4000" data-easing="easeOutBack"><h3>Online platform to upload your photos</h3></div>

		    <div class="caption sfb small-caption mobile-hide"  data-x="right" data-y="center" data-speed="500" data-voffset="10" data-start="4400" data-easing="easeOutBack"><h3>Lamination Services</h3></div>

		    <div class="caption sfb small-caption mobile-hide"  data-x="right" data-y="center" data-speed="500" data-voffset="50" data-start="4800" data-easing="easeOutBack"><h3>Framing Services</h3></div>

		  <!-- <div class="caption sfb mobile-hide"  data-x="center" data-y="bottom" data-voffset="-80" data-speed="500" data-start="1900" data-easing="easeOutBack"><h2>Multi-purpose HTML5 & CSS3 template</h2></div>-->

		 </li>




		</ul>

	</div>
</div>
<!--  =========================  -->
<!--  = end Slider Revolution =  -->
<!--  =========================  -->
