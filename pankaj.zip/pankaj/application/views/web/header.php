<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>

<!--  ====================  -->
<!--  = Basic Page Needs =  -->
<!--  ====================  -->
	<meta charset="utf-8">
	<title>Picture Perfect</title>
	<meta name="description" content="PureScroll is a truly powerful HTML template combining responsive elements with parallax effect to one incredible package." />
	<meta name="keywords" content="parallax, onepage, html webdesign, web design, web template, ios7, apple, flat, flat design html, single page, one page web design, landing page template" />

<!--  ===========  -->
<!--  = Favicon =  -->
<!--  ===========  -->
<link rel="shortcut icon" href="<?php echo base_url(); ?>front/images/favicon.ico" type="image/x-icon" />
<link rel="apple-touch-icon" href="<?php echo base_url(); ?>front/images/apple-touch-icon.png" />
<link rel="apple-touch-icon" sizes="57x57" href="<?php echo base_url(); ?>front/images/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon" sizes="72x72" href="<?php echo base_url(); ?>front/images/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url(); ?>front/images/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon" sizes="114x114" href="<?php echo base_url(); ?>front/images/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon" sizes="120x120" href="<?php echo base_url(); ?>front/images/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon" sizes="144x144" href="<?php echo base_url(); ?>front/images/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon" sizes="152x152" href="<?php echo base_url(); ?>front/images/apple-touch-icon-152x152.png" />


<!--  ===================  -->
<!--  = Mobile specific =  -->
<!--  ===================  -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!--  =======  -->
<!--  = CSS =  -->
<!--  =======  -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>front/css/base.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>front/css/skeleton.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>front/scripts/rs-plugin/css/settings.css" media="screen" />
	<link rel="stylesheet" href="<?php echo base_url(); ?>front/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>front/css/prettyPhoto.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>front/css/layout.css">




<!--  ================  -->
<!--  = Google fonts =  -->
<!--  ================  -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,700' rel='stylesheet' type='text/css'>




<!--  =====================  -->
<!--  = IE specific HTML5 =  -->
<!--  =====================  -->
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->

</head>
<body>



<!--<div id="body-preloader">
	<div class="table-center-vertically">
		<h1><span class="blue">loading</span><span class="red">pictureperfect</span></h1>
	</div>
</div>-->

<a href="#"><div id="scroll-up" class="translate-default-down"><i class="fa fa-chevron-up"></i></div></a>



<div id="top-wrapper"><!-- Top wrapper full width and height -->


					<div class="color-bar">
						<div class="c-one"></div>
						<div class="c-two"></div>
						<div class="c-three"></div>
						<div class="c-four"></div>
						<div class="c-five"></div>
					</div>

<div id="top-small-menu">
	<div class="small-menu-container">
		<div class="top-social-icons">
			<a href="#"><i class="fa fa-facebook"></i></a>
			<a href="#"><i class="fa fa-twitter"></i></a>
			<a href="#"><i class="fa fa-linkedin"></i></a>
			<a href="#"><i class="fa fa-google-plus"></i></a>
			<a href="#"><i class="fa fa-pinterest"></i></a>
			<a href="#"><i class="fa fa-instagram"></i></a>
			<a href="#"><i class="fa fa-skype"></i></a>
		</div>
		<h2><i class="fa fa-phone"></i>Call Us: +91 9942025157</h2>
	</div>
</div>

<div class="top-logo">
	<div class="top-logo-bg">
		<img src="<?php echo base_url(); ?>front/images/logo.png" alt="logo">
	</div>
	<div class="end-triangle"></div>
</div>
