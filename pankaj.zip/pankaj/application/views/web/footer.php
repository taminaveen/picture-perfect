<!-- Buy now -->
<!--<div id="buy-now">

	<h1><span class="slabtext"><i class="fa fa-heart-o"></i> I want this template!</span></h1>
</div>-->
<!-- end Buy now -->


<!-- Footer -->
<section id="footer-section" class="full-width">
	<div class="container">

		<!-- Footer logo(text) -->
		<div class="logo-holder">
			<h1><span class="slabtext">Picture Perfect</span></h1>
		</div>
		<!-- [end] Footer logo(text) -->

		<!-- Social networks -->
		<ul class="social-icons">
			<li><a href="#" target="_blank"><i class="fa fa-linkedin"></i></a></li><li><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li><li><a href="#" target="_blank"><i class="fa fa-facebook"></i></a></li><li><a href="#" target="_blank"><i class="fa fa-google-plus"></i></a></li><li><a href="#" target="_blank"><i class="fa fa-youtube"></i></a></li><li><a href="#" target="_blank"><i class="fa fa-tumblr"></i></a></li><li><a href="#" target="_blank"><i class="fa fa-pinterest"></i></a></li><li><a href="#" target="_blank"><i class="fa fa-dribbble"></i></a></li><li><a href="#" target="_blank"><i class="fa fa-dropbox"></i></a></li><li><a href="#" target="_blank"><i class="fa fa-foursquare"></i></a></li><li><a href="#" target="_blank"><i class="fa fa-flickr"></i></a></li><li><a href="#" target="_blank"><i class="fa fa-instagram"></i></a></li>
		</ul>
		<!-- [end] Social networks -->

		<!-- Copyright -->
		<div class="copyright-notice">
			<h2><span class="bold">&copy; 2017 Picture Perfect. All rights reserved.</span></h2>
		</div>
		<!-- [end] Copyright -->

	</div>
</section>
<!-- [end] Footer -->


</body>


<!--  ===========  -->
<!--  = jQuery  =  -->
<!--  ===========  -->

<!-- Using Google DNS -->
<!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script> -->

<!-- Using local jQuery library -->
<script type="text/javascript" src="<?php echo base_url(); ?>front/scripts/jquery-1.10.2.min.js"></script>


<!--  ======================  -->
<!--  = Additional scripts =  -->
<!--  ======================  -->



<script type="text/javascript" src="<?php echo base_url(); ?>front/scripts/rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>front/scripts/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>front/scripts/jquery.parallax-1.1.3.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>front/scripts/jquery.scrollTo-1.4.2-min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>front/scripts/jquery.flexslider.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>front/scripts/jquery.isotope.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>front/scripts/jquery.typed.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>front/scripts/jquery.prettyPhoto.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>front/scripts/jquery.fitvids.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>front/scripts/jquery.easing.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>front/scripts/jquery.slabtext.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>front/scripts/jquery.appear.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>front/scripts/jquery.countTo.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>front/scripts/jquery.jetmenu.js"></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false
"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>front/scripts/jquery.smoothscroll.js"></script>




<!--  ==================  -->
<!--  = Custom scripts =  -->
<!--  ==================  -->
<script type="text/javascript" src="<?php echo base_url(); ?>front/scripts/scripts.js"></script>


</html>