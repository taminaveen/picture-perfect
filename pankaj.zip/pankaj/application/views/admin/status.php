<div id="myModal1" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="myModalLabel1">Update Order Status</h3>
    </div>
    <?php $attrib = array('class' => 'form-horizontal', 'id' => 'Updateform');
        echo form_open_multipart("orders/update_status/" . $id, $attrib); ?>
    <div class="modal-body">
        <div class="control-group">
        	<label class="control-label"><?= lang("status"); ?></label>
            <div class="controls">                
                <?php $st = array('completed' => "Completed", 'address printing' => "Address printing", 'cover letter' => "Cover Letter Printing", 'thanks letter' => "Thanks Letter Printing");
                echo form_dropdown('status', $st, '', 'class="chzn-select input-large" id="qustatus"'); ?>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
    </div>
    <?php echo form_close(); ?>
</div>
