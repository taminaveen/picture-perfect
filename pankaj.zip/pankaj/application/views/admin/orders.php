<script>
$(document).ready(function() {
	 $('#sample_1').dataTable({
		"sDom": "<'row-fluid'<'span6'l><'span6'f>r>t<'row-fluid'<'span6'i><'span6'p>>",			
		"sPaginationType": "bootstrap",
		"oLanguage": {
			"sLengthMenu": "_MENU_ records per page",
			"oPaginate": {
				"sPrevious": "Prev",
				"sNext": "Next"
			}
		},
		"oTableTools": {
			"sSwfPath": "<?php echo base_url(); ?>theme/assets/data-tables/swf/copy_csv_xls_pdf.swf",
			"aButtons": [
							{
								"sExtends": "csv",
								"sFileName": "customers.csv",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
							{
								"sExtends": "xls",
								"sFileName": "customers.xls",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
							{
								"sExtends": "pdf",
								"sFileName": "customers.pdf",
								"sPdfOrientation": "landscape",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
					],
			
		},
		"aoColumns": [null, null, null, null, null, {"mRender": row_status}, null]	
	});
	
	$('#sample_2').dataTable({
		"sDom": "<'row-fluid'<'span6'l><'span6'f>r>t<'row-fluid'<'span6'i><'span6'p>>",			
		"sPaginationType": "bootstrap",
		"oLanguage": {
			"sLengthMenu": "_MENU_ records per page",
			"oPaginate": {
				"sPrevious": "Prev",
				"sNext": "Next"
			}
		},
		"oTableTools": {
			"sSwfPath": "<?php echo base_url(); ?>theme/assets/data-tables/swf/copy_csv_xls_pdf.swf",
			"aButtons": [
							{
								"sExtends": "csv",
								"sFileName": "customers.csv",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
							{
								"sExtends": "xls",
								"sFileName": "customers.xls",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
							{
								"sExtends": "pdf",
								"sFileName": "customers.pdf",
								"sPdfOrientation": "landscape",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
					],
			
		},
		"aoColumns": [null, null, null, null, null, {"mRender": row_status}]	
	});
	
	$('#sample_3').dataTable({
		"sDom": "<'row-fluid'<'span6'l><'span6'f>r>t<'row-fluid'<'span6'i><'span6'p>>",			
		"sPaginationType": "bootstrap",
		"oLanguage": {
			"sLengthMenu": "_MENU_ records per page",
			"oPaginate": {
				"sPrevious": "Prev",
				"sNext": "Next"
			}
		},
		"oTableTools": {
			"sSwfPath": "<?php echo base_url(); ?>theme/assets/data-tables/swf/copy_csv_xls_pdf.swf",
			"aButtons": [
							{
								"sExtends": "csv",
								"sFileName": "customers.csv",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
							{
								"sExtends": "xls",
								"sFileName": "customers.xls",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
							{
								"sExtends": "pdf",
								"sFileName": "customers.pdf",
								"sPdfOrientation": "landscape",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
					],
			
		},
		"aoColumns": [null, null, null, null, null, {"mRender": row_status}]	
	});
	
	$('#sample_4').dataTable({
		"sDom": "<'row-fluid'<'span6'l><'span6'f>r>t<'row-fluid'<'span6'i><'span6'p>>",			
		"sPaginationType": "bootstrap",
		"oLanguage": {
			"sLengthMenu": "_MENU_ records per page",
			"oPaginate": {
				"sPrevious": "Prev",
				"sNext": "Next"
			}
		},
		"oTableTools": {
			"sSwfPath": "<?php echo base_url(); ?>theme/assets/data-tables/swf/copy_csv_xls_pdf.swf",
			"aButtons": [
							{
								"sExtends": "csv",
								"sFileName": "customers.csv",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
							{
								"sExtends": "xls",
								"sFileName": "customers.xls",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
							{
								"sExtends": "pdf",
								"sFileName": "customers.pdf",
								"sPdfOrientation": "landscape",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
					],
			
		},
		"aoColumns": [null, null, null, null, null, {"mRender": row_status}]	
	});
	
	$('#sample_5').dataTable({
		"sDom": "<'row-fluid'<'span6'l><'span6'f>r>t<'row-fluid'<'span6'i><'span6'p>>",			
		"sPaginationType": "bootstrap",
		"oLanguage": {
			"sLengthMenu": "_MENU_ records per page",
			"oPaginate": {
				"sPrevious": "Prev",
				"sNext": "Next"
			}
		},
		"oTableTools": {
			"sSwfPath": "<?php echo base_url(); ?>theme/assets/data-tables/swf/copy_csv_xls_pdf.swf",
			"aButtons": [
							{
								"sExtends": "csv",
								"sFileName": "customers.csv",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
							{
								"sExtends": "xls",
								"sFileName": "customers.xls",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
							{
								"sExtends": "pdf",
								"sFileName": "customers.pdf",
								"sPdfOrientation": "landscape",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
					],
			
		},
		"aoColumns": [null, null, null, null, null, {"mRender": row_status}]	
	});
	
	$('#sample_6').dataTable({
		"sDom": "<'row-fluid'<'span6'l><'span6'f>r>t<'row-fluid'<'span6'i><'span6'p>>",			
		"sPaginationType": "bootstrap",
		"oLanguage": {
			"sLengthMenu": "_MENU_ records per page",
			"oPaginate": {
				"sPrevious": "Prev",
				"sNext": "Next"
			}
		},
		"oTableTools": {
			"sSwfPath": "<?php echo base_url(); ?>theme/assets/data-tables/swf/copy_csv_xls_pdf.swf",
			"aButtons": [
							{
								"sExtends": "csv",
								"sFileName": "customers.csv",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
							{
								"sExtends": "xls",
								"sFileName": "customers.xls",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
							{
								"sExtends": "pdf",
								"sFileName": "customers.pdf",
								"sPdfOrientation": "landscape",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
					],
			
		},
		"aoColumns": [null, null, null, null, null, {"mRender": row_status}]	
	});

	$('#sample_1_wrapper .dataTables_filter input').addClass("input-medium"); // modify table search input
	$('#sample_1_wrapper .dataTables_length select').addClass("input-mini"); // modify table per page dropdown
});
</script>
<div id="main-content">
         <!-- BEGIN PAGE CONTAINER-->
     <div class="container-fluid">
        <!-- BEGIN PAGE HEADER-->   
        <div class="row-fluid">
           <div class="span12">
            	<?php if($message) { echo "<div class=\"alert alert-danger\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>
<?php if($success_message) { echo "<div class=\"alert alert-success\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $success_message . "</div>"; } ?>
           </div>
        </div>
        <!-- END PAGE HEADER-->
        <!-- BEGIN ADVANCED TABLE widget-->
        <div class="row-fluid">
            <div class="span12">
                <!-- BEGIN TAB PORTLET-->
                <div class="widget widget-tabs purple">
                    <div class="widget-title">
                        <h4><i class="icon-reorder"></i> <?php echo $page_title; ?></h4>
                    </div>
                    <div class="widget-body">
                        <div class="tabbable ">
                            <ul class="nav nav-tabs">
                                <li><a href="#widget_tab6" data-toggle="tab">Dispatch System</a></li>
                                <li><a href="#widget_tab5" data-toggle="tab">Thanks Letter</a></li>
                                <li><a href="#widget_tab4" data-toggle="tab">Cover Letter Printing</a></li>
                                <li><a href="#widget_tab3" data-toggle="tab">Address Printing</a></li>
                                <li><a href="#widget_tab2" data-toggle="tab">Completed</a></li>
                                <li class="active"><a href="#widget_tab1" data-toggle="tab">Pending</a></li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane active" id="widget_tab1">
                                   <table class="table table-striped table-bordered" id="sample_1">
                                        <thead>
                                            <tr>
                                                <th>S.no</th>
                                                <th>Order No</th>
                                                <th>Title</th>
                                                <th>Customer</th>
                                                <th>Order Date</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i =0;
                                                $query = $this->db->query("select * from printing_orders where status='pending' order by id desc");
                                                $result = $query->result();
                                                foreach($result as $row):
                                                $i++;
                                             ?>
                                            <tr class="odd gradeX">
                                                <td><?php echo $i;?></td>
                                                <td><?php echo $row->order_no;?></td>
                                                <td><?php echo $row->title;?></td>
                                                <td><?php echo $row->customer_name;?></td>
                                                <td><?php echo date("d-m-Y",strtotime($row->order_date));?></td>
                                                <td><?php echo $row->status; ?></td>
                                                <td><a style="text-decoration:none;" href="<?php site_url('orders/update_status/'.$row->id)?>" data-toggle='modal' data-target='#myModal1' class='tip' title="Update Order Status"><i class="icon-edit"></i></a></td>
                                            </tr>
                                        <?php endforeach;?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="tab-pane" id="widget_tab2">
                                    <table class="table table-striped table-bordered" id="sample_2">
                                        <thead>
                                            <tr>
                                                <th>S.no</th>
                                                <th>Order No</th>
                                                <th>Title</th>
                                                <th>Customer</th>
                                                <th>Order Date</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $j =0;
                                                $query2 = $this->db->query("select * from printing_orders where status='completed' order by id desc");
                                                $result2 = $query2->result();
                                                foreach($result2 as $row2):
                                                $j++;
                                             ?>
                                            <tr class="odd gradeX">
                                                <td><?php echo $j;?></td>
                                                <td><?php echo $row2->order_no;?></td>
                                                <td><?php echo $row2->title;?></td>
                                                <td><?php echo $row2->customer_name;?></td>
                                                <td><?php echo date("d-m-Y",strtotime($row2->order_date));?></td>
                                                <td><?php echo $row2->status; ?>  </td>
                                            </tr>
                                        <?php endforeach;?>
                                        </tbody>
                                    </table>        
                                </div>
                                <div class="tab-pane" id="widget_tab3">
                                    <table class="table table-striped table-bordered" id="sample_3">
                                        <thead>
                                            <tr>
                                                <th>S.no</th>
                                                <th>Order No</th>
                                                <th>Title</th>
                                                <th>Customer</th>
                                                <th>Order Date</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $k =0;
                                                $query3 = $this->db->query("select * from printing_orders where status='address printing' order by id desc");
                                                $result3 = $query3->result();
                                                foreach($result3 as $row3):
                                                $k++;
                                             ?>
                                            <tr class="odd gradeX">
                                                <td><?php echo $k;?></td>
                                                <td><?php echo $row3->order_no;?></td>
                                                <td><?php echo $row3->title;?></td>
                                                <td><?php echo $row3->customer_name;?></td>
                                                <td><?php echo date("d-m-Y",strtotime($row3->order_date));?></td>
                                                <td><?php echo $row3->status; ?>  </td>
                                            </tr>
                                        <?php endforeach;?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="tab-pane" id="widget_tab4">
                                    <table class="table table-striped table-bordered" id="sample_4">
                                        <thead>
                                            <tr>
                                                <th>S.no</th>
                                                <th>Order No</th>
                                                <th>Title</th>
                                                <th>Customer</th>
                                                <th>Order Date</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $l =0;
                                                $query4 = $this->db->query("select * from printing_orders where status='cover letter' order by id desc");
                                                $result4 = $query4->result();
                                                foreach($result4 as $row4):
                                                $l++;
                                             ?>
                                            <tr class="odd gradeX">
                                                <td><?php echo $l;?></td>
                                                <td><?php echo $row4->order_no;?></td>
                                                <td><?php echo $row4->title;?></td>
                                                <td><?php echo $row4->customer_name;?></td>
                                                <td><?php echo date("d-m-Y",strtotime($row4->order_date));?></td>
                                                <td><?php echo $row4->status; ?>  </td>
                                            </tr>
                                        <?php endforeach;?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="tab-pane" id="widget_tab5">
                                    <table class="table table-striped table-bordered" id="sample_5">
                                        <thead>
                                            <tr>
                                                <th>S.no</th>
                                                <th>Order No</th>
                                                <th>Title</th>
                                                <th>Customer</th>
                                                <th>Order Date</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $m =0;
                                                $query5 = $this->db->query("select * from printing_orders where status='thanks letter' order by id desc");
                                                $result5 = $query5->result();
                                                foreach($result5 as $row5):
                                                $m++;
                                             ?>
                                            <tr class="odd gradeX">
                                                <td><?php echo $m;?></td>
                                                <td><?php echo $row5->order_no;?></td>
                                                <td><?php echo $row5->title;?></td>
                                                <td><?php echo $row5->customer_name;?></td>
                                                <td><?php echo date("d-m-Y",strtotime($row5->order_date));?></td>
                                                <td><?php echo $row5->status; ?>  </td>
                                            </tr>
                                        <?php endforeach;?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="tab-pane" id="widget_tab6">
                                    <table class="table table-striped table-bordered" id="sample_6">
                                        <thead>
                                            <tr>
                                                <th>S.no</th>
                                                <th>Order No</th>
                                                <th>Title</th>
                                                <th>Customer</th>
                                                <th>Order Date</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $n =0;
                                                $query6 = $this->db->query("select * from printing_orders where status='dispatch system' order by id desc");
                                                $result6 = $query6->result();
                                                foreach($result6 as $row6):
                                                $n++;
                                             ?>
                                            <tr class="odd gradeX">
                                                <td><?php echo $n;?></td>
                                                <td><?php echo $row6->order_no;?></td>
                                                <td><?php echo $row6->title;?></td>
                                                <td><?php echo $row6->customer_name;?></td>
                                                <td><?php echo date("d-m-Y",strtotime($row6->order_date));?></td>
                                                <td><?php echo $row6->status; ?>  </td>
                                            </tr>
                                        <?php endforeach;?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END TAB PORTLET-->
            </div>
        </div>
        
</div>
</div>

<!-- END ADVANCED TABLE widget-->
</div>
 <!-- END PAGE CONTAINER-->
</div>


<div id="myModal1" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="myModalLabel1">Update Order Status</h3>
    </div>
    <?php $attrib = array('class' => 'form-horizontal', 'id' => 'Updateform');
        echo form_open_multipart("orders/update_status/", $attrib); ?>
    <div class="modal-body">
        <div class="control-group">
        	<label class="control-label">Status</label>
            <div class="controls">                
                <?php $st = array('completed' => "Completed", 'address printing' => "Address printing", 'cover letter' => "Cover Letter Printing", 'thanks letter' => "Thanks Letter Printing");
                echo form_dropdown('status', $st, '', 'class="chzn-select input-large" id="qustatus"'); ?>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
    </div>
    <?php echo form_close(); ?>
</div>