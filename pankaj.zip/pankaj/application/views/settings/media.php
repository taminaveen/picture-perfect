<div id="main-content">
         <!-- BEGIN PAGE CONTAINER-->
     <div class="container-fluid">
        <!-- BEGIN PAGE HEADER-->   
        <div class="row-fluid">
           <div class="span12">
            	<?php if($message) { echo "<div class=\"alert alert-danger\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>
<?php if($success_message) { echo "<div class=\"alert alert-success\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $success_message . "</div>"; } ?>
           </div>
        </div>
        
        <div class="row-fluid">
            <div class="span12"> 	           
               <div class="widget red">
                    <div class="widget-title">
                        <h4><i class="icon-list"></i><?php echo $page_title; ?></h4>
                            <span class="tools">
                                <a href="javascript:;" class="icon-chevron-down"></a>
                                <a href="javascript:;" class="icon-remove"></a>
                            </span>
                    </div>
                    <div class="widget-body">
						<?php $attrib = array('class' => 'form-horizontal', 'method'=> 'POST'); echo form_open("admin/media/save_params", $attrib); ?>
        <!-- allowed extensions -->
                        <div class="control-group">
                          <label for="allowed_types" class="control-label" data-toggle="tooltip" title="Allowed extension types (separated by comma)">Allowed Types</label>
                          <div class="controls"><input type="text" class="form-control form-control-sm" id="allowed_types" name="allowed_types" placeholder="Allowed Extensions (separated by comma)" value="<?php echo $this->config->item('allowed_types'); ?>"></div>
                        </div>
                        <!-- msx. file size -->                  
                        <div class="control-group">
                          <label for="max_size" class="control-label" data-toggle="tooltip" title="Maximum file size (MB) can be uploaded">Maximum Size (in MB)</label>
                          <div class="controls"><input type="number" min="1" class="form-control form-control-sm" id="max_size" name="max_size" placeholder="Maximum size (MB)" value="<?php echo $this->config->item('max_size'); ?>"></div>
                        </div>
                        <!-- max. width -->
                        <div class="control-group">
                          <label for="max_width" class="control-label" data-toggle="tooltip" title="Maximum width of images allowed to be uploaded">Maximum Width (in Px)</label>
                          <div class="controls"><input type="number" min="1" class="form-control form-control-sm" id="max_width" name="max_width" placeholder="Maximum Width (in Px for images)" value="<?php echo $this->config->item('max_width'); ?>"></div>
                        </div>
                        <!-- max. height -->
                        <div class="control-group">
                          <label for="max_height" class="control-label" data-toggle="tooltip" title="Maximum height of images allowed to be uploaded">Maximum Height (in Px)</label>
                          <div class="controls"><input type="number" min="1" class="form-control form-control-sm" id="max_height" name="max_height" placeholder="Maximum Height (in Px for images)" value="<?php echo $this->config->item('max_height'); ?>"></div>
                        </div>   
                        <!-- media folder -->                 
                        <div class="control-group">
                          <label for="media_path" class="control-label" data-toggle="tooltip" title="Valid path to media folder">Media Folder</label>
                          <div class="controls"><input type="text" class="form-control form-control-sm" id="media_path" name="media_path" placeholder="Media folder path" value="<?php echo $this->config->item('media_path'); ?>"></div>
                        </div> 
                        <!-- max. file name -->         
                        <div class="control-group">
                          <label for="max_filename" class="control-label" data-toggle="tooltip" title="Maximum characters of file name to be uploaded (0: Unlimited)">Maximum File Name</label>
                          <div class="controls"><input type="number" min="0" class="form-control form-control-sm" id="max_filename" name="max_filename" placeholder="Maximum filename (in characters)" value="<?php echo $this->config->item('max_filename'); ?>"></div>
                        </div>
                        <!-- max. files -->         
                        <div class="control-group">
                          <label for="max_files" class="control-label" data-toggle="tooltip" title="Maximum number of files that can uploaded once">Maximum Files</label>
                          <div class="controls"><input type="number" min="0" class="form-control form-control-sm" id="max_files" name="max_files" placeholder="Maximum no. of files" value="<?php echo $this->config->item('max_files'); ?>"></div>
                        </div>
                        <!-- overwrite-->
                        <div class="control-group">
                          <label class="control-label" data-toggle="tooltip" title="If checked files with same name and type will be overwritten">Overwrite</label>
                          <div class="controls"><input type="checkbox" name="overwrite" <?php if($this->config->item('overwrite')) echo 'checked'; ?>></div>            
                        </div> 
                        <!-- remove spaces -->
                        <div class="control-group">
                          <label class="control-label" data-toggle="tooltip" title="Remove spaces between name of uploaded files">Remove Spaces</label>
                          <div class="controls"><input type="checkbox" name="remove_spaces" <?php if($this->config->item('remove_spaces')) echo 'checked'; ?>></div>            
                        </div> 
                        <!-- encrypt media name -->
                        <div class="control-group">
                          <label class="control-label" data-toggle="tooltip" title="Encrypt name of uploaded files">Encrypt File Name</label>
                          <div class="controls"><input type="checkbox" name="encrypt_name" <?php if($this->config->item('encrypt_name')) echo 'checked'; ?>></div>            
                        </div>
                        <!-- restore default settings -->
                        <div class="control-group">
                          <label class="control-label" data-toggle="tooltip" title="Restore default settings of media manager">Restore Default Settings</label>
                          <div class="controls"><input type="checkbox" name="restore"></div>            
                        </div> 
                        
                        <div class="control-group">
                          <label class="control-label"></label>
                          <div class="controls"><p class="alert alert-info"><strong>Note: </strong>Set file-size, width, height, file-name to 0 for no limit</p></div>            
                        </div>
                        
                        <div class="form-actions">
					 		<?php echo form_submit('submit', $this->lang->line("update_media_settings"), 'class="btn btn-sm btn-primary"');?> 
               			</div>
      				<?php echo form_close();?>
					  </div>
                </div>
            </div>
        </div>
    
    
 	</div>
</div>