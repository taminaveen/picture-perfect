<div id="main-content">
         <!-- BEGIN PAGE CONTAINER-->
     <div class="container-fluid">
        <!-- BEGIN PAGE HEADER-->   
        <div class="row-fluid">
           <div class="span12">
            	<?php if($message) { echo "<div class=\"alert alert-danger\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>
<?php if($success_message) { echo "<div class=\"alert alert-success\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $success_message . "</div>"; } ?>
           </div>
        </div>

    <div class="row-fluid">
        <div class="span12">            
           <div class="widget red">
                <div class="widget-title">
                    <h4><i class="icon-list"></i><?php echo $page_title; ?></h4>
                        <span class="tools">
                            <a href="javascript:;" class="icon-chevron-down"></a>
                            <a href="javascript:;" class="icon-remove"></a>
                        </span>
                </div>
                <div class="widget-body">
                <?php $attrib = array('class' => 'form-horizontal'); echo form_open("settings/system_setting", $attrib); ?>
                	<div class="control-group">
                      <label class="control-label" for="site_name"><?php echo $this->lang->line("site_name"); ?></label>
                      <div class="controls"> <?php echo form_input('site_name', $settings->site_name, 'class="input-large" id="site_name" required="required" data-error="'.$this->lang->line("site_name").' '.$this->lang->line("is_required").'"'); ?> </div>
                    </div>
                    
                    <div class="control-group">
                      <label class="control-label" for="language"><?php echo $this->lang->line("language"); ?></label>
                      <div class="controls">
                        <?php 
                          $lang = array (
                                            'english' => 'English',
                                        );
                            echo form_dropdown('language', $lang, $settings->language, 'class="chzn-select" data-placeholder="'.$this->lang->line("select").' '.$this->lang->line("language").'" title="'.$this->lang->line("language_tip").'" required="required" data-error="'.$this->lang->line("language").' '.$this->lang->line("is_required").'"'); ?>
                      </div>
                    </div>
                    
                    <div class="control-group">
                      <label class="control-label" for="currency_code"><?php echo $this->lang->line("currency_code"); ?></label>
                      <div class="controls"> <?php echo form_input('currency_prefix', $settings->currency_prefix, 'class="input-large" id="currency_code" title="'.$this->lang->line("currency_code_tip").'" required="required" data-error="'.$this->lang->line("currency_code").' '.$this->lang->line("is_required").'"');?> </div>
                    </div>
                    
                   <div class="control-group">
                      <label class="control-label" for="default_discount"><?php echo $this->lang->line("default_discount"); ?></label>
                      <div class="controls">
                        <?php 
                          foreach($discounts as $discount){
                                $ds[$discount->id] = $discount->name;
                            }
                            echo form_dropdown('default_discount', $ds, $settings->default_discount, 'class="chzn-select" data-placeholder="'.$this->lang->line("select").' '.$this->lang->line("default_discount").'" required="required" data-error="'.$this->lang->line("default_discount").' '.$this->lang->line("is_required").'"'); ?>
                      </div>
                  </div>
                  
                   <div class="control-group">
                      <label class="control-label" for="theme"><?php echo $this->lang->line("theme"); ?></label>
                      <div class="controls">
                        <?php 
                            
                          $th = array (
                                            'default' => 'Theme 1', 
                                            'grey' => 'Theme 2',
                                            'green' => 'Theme 3',
                                            'purple' => 'Theme 4',
                                            'red' => 'Theme 5');
                            echo form_dropdown('theme', $th, $settings->theme, 'class="chzn-select" data-placeholder="'.$this->lang->line("select").' '.$this->lang->line("theme").'" required="required" data-error="'.$this->lang->line("theme").' '.$this->lang->line("is_required").'"'); ?>
                      </div>
                   </div>
                   
                   <div class="control-group">
                      <label class="control-label" for="tax_rate2"><?php echo $this->lang->line("rows_per_page"); ?></label>
                      <div class="controls">
                        <?php 
                            $options = array (
                                            '10' => '10', 
                                            '25' => '25',
                                            '50' => '50',
                                            '100' => '100',
                                            '-1' => 'All (not recommended)');
                            echo form_dropdown('rows_per_page', $options, $settings->rows_per_page, 'class="chzn-select" data-placeholder="'.$this->lang->line("select").' '.$this->lang->line("rows_per_page").'" title="'.$this->lang->line("rows_per_page_tip").'" required="required" data-error="'.$this->lang->line("rows_per_page").' '.$this->lang->line("is_required").'"'); ?>
                      </div>
                    </div>
                    
                    <div class="control-group">
                      <label class="control-label" for="date_format"><?php echo $this->lang->line("date_format"); ?></label>
                      <div class="controls">
                        <?php 
                          foreach($date_formats as $date_format){
                                $dt[$date_format->id] = $date_format->js;
                            }
                            echo form_dropdown('date_format', $dt, $settings->dateformat, 'class="chzn-select" data-placeholder="'.$this->lang->line("select").' '.$this->lang->line("date_format").'" required="required" data-error="'.$this->lang->line("date_format").' '.$this->lang->line("is_required").'"'); ?>
                      </div>
                    </div> 
                    
                <div class="form-actions">
					 <?php echo form_submit('submit', $this->lang->line("update_settings"), 'class="btn btn-success"');?> 
                </div>
                <?php echo form_close();?>
                  </div>
                </div>
            </div>
        </div>
    
    
 	</div>
</div>