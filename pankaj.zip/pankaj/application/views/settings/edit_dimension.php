<script>
$(function(){
	$("#form1").validate({
		rules: {
                dimention: "required",
                printing: {
                    required: true,
                    number: true
                },               
                lamination: {
                    required: true,
                    number: true
                },
                framing: {
                    required: true,
					number: true
                },
            },
            messages: {
                dimention: "Please enter your dimention",                
                printing: "Please enter numeric values only",                              
                lamination: "Please enter numeric values only",
				framing: "Please enter numeric values only",
            }	
	});
});
</script>
<div id="main-content">
         <!-- BEGIN PAGE CONTAINER-->
     <div class="container-fluid">
        <!-- BEGIN PAGE HEADER-->   
        <div class="row-fluid">
           <div class="span12">
            	<?php if($message) { echo "<div class=\"alert alert-danger\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>
           </div>
        </div>
        <!-- END PAGE HEADER-->
        <!-- BEGIN ADVANCED TABLE widget-->
        <div class="row-fluid">
            <div class="span12">
            <!-- BEGIN EXAMPLE TABLE widget-->
            <div class="widget green">
                <div class="widget-title">
                    <h4><i class="icon-edit"></i><?php echo $page_title; ?></h4>
                        <span class="tools">
                            <a href="javascript:;" class="icon-chevron-down"></a>
                            <a href="javascript:;" class="icon-remove"></a>
                        </span>
                </div>
                <div class="widget-body">
                <?php echo form_open("settings/edit_dimension/".$id,'class="form-horizontal cmxform" id="form1" ');?>
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('dimention');?></label>
                        <div class="controls">
                            <?php echo form_input('dimention', $roles->name, 'class="input-xlarge" id="dimention" ');?>
                        </div>
                    </div>
                    
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('printing_cost');?></label>
                        <div class="controls">
                            <?php echo form_input('printing', $roles->printing, 'class="input-xlarge text-right" id="printing" ');?>
                        </div>
                    </div>
                    
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('lamination_cost');?></label>
                        <div class="controls">
                            <?php echo form_input('lamination', $roles->lamination, 'class="input-xlarge text-right" id="lamination" ');?>
                        </div>
                    </div>
                    
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('framing_cost');?></label>
                        <div class="controls">
                            <?php echo form_input('framing', $roles->framing, 'class="input-xlarge text-right" id="framing" ');?>
                        </div>
                    </div>
                    
                   <div class="form-actions">
                        <?php echo form_submit('submit', lang('edit_dimention'),'class="btn btn-primary"');?>
                    </div>
                    <?php echo form_close();?>
                </div>
            </div>
            <!-- END EXAMPLE TABLE widget-->
            </div>
        </div>

        <!-- END ADVANCED TABLE widget-->
     </div>
         <!-- END PAGE CONTAINER-->
      </div>
