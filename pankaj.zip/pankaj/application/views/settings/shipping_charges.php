<script>
$(document).ready(function() {
	var _dataTable = $('#sample_1').dataTable({
		"sDom": "<'row-fluid'<'span6'l><'span6'f>r>t<'row-fluid'<'span6'i><'span6'p>>",		
		"sPaginationType": "bootstrap",
		"oLanguage": {
			"sLengthMenu": "_MENU_ records per page",
			"oPaginate": {
				"sPrevious": "Prev",
				"sNext": "Next"
			}
		},
		/*"oTableTools": {
			"sSwfPath": "<?php echo base_url(); ?>theme/assets/data-tables/swf/copy_csv_xls_pdf.swf",
			"aButtons": [
							{
								"sExtends": "csv",
								"sFileName": "customers.csv",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
							{
								"sExtends": "xls",
								"sFileName": "customers.xls",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
							{
								"sExtends": "pdf",
								"sFileName": "customers.pdf",
								"sPdfOrientation": "landscape",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
						],
			
		},*/
		//"aoColumns": [null, null, null, null, null null,null]
	/*	"aoColumnDefs": [{
			    'bSortable': false,
                "aTargets": [0],
                "aoColumns": [null, null, null, null, null null,null]
            }]*/
		/*"aoColumnDefs": [null, null,{
			'bSortable': false,
			'aTargets': [2],
			'mRender':format_date
		}, null, null null, null],*/
		 "aoColumnDefs": [ {"bSortable": false, "aTargets": [0]} ]
	});

	$('#sample_1_wrapper .dataTables_filter input').addClass("input-medium"); // modify table search input
	$('#sample_1_wrapper .dataTables_length select').addClass("input-mini"); // modify table per page dropdown
});
</script>

<div id="main-content">
         <!-- BEGIN PAGE CONTAINER-->
     <div class="container-fluid">
        <!-- BEGIN PAGE HEADER-->   
        <div class="row-fluid">
           <div class="span12">
            	<?php if($message) { echo "<div class=\"alert alert-danger\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>
<?php if($success_message) { echo "<div class=\"alert alert-success\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $success_message . "</div>"; } ?>
           </div>
        </div>
        <!-- END PAGE HEADER-->
        <!-- BEGIN ADVANCED TABLE widget-->
        <div class="row-fluid">
            <div class="span12">
            <!-- BEGIN EXAMPLE TABLE widget-->
            <div class="widget blue">
                <div class="widget-title">
                    <h4><i class="icon-list"></i><?php echo $page_title; ?></h4>
                        <span class="tools">
                            <a href="javascript:;" class="icon-chevron-down"></a>
                            <a href="javascript:;" class="icon-remove"></a>
                        </span>
                </div>
                <div class="widget-body">
                    <table class="table table-striped table-bordered" id="sample_1">
                        <thead>
                        <tr>
                            <th><?php echo lang('weight');?></th>
                            <th><?php echo lang('local');?></th>
                            <th><?php echo lang('upto200');?></th>
                            <th><?php echo lang('201to1000');?></th>
                            <th><?php echo lang('1001to2000');?></th>
                            <th><?php echo lang('above2000');?></th>                            
                            <th><?php echo lang('actions');?></th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php if(is_array($shippings)){foreach ($shippings as $shipping): ?>
                            <tr class="odd gradeX">
                                <td><?php echo $shipping->weight;?></td>
                                <td><?php echo $shipping->local;?></td>                                
                                <td><?php echo $shipping->d1; ?></td>
                                <td><?php echo $shipping->d2;?></td>
                                <td><?php echo $shipping->d3; ?></td>
                                <td><?php echo $shipping->d4;?></td>
                                <td><?php echo anchor("settings/edit_deliverycharge/".$shipping->id, 'Edit') ;?></td>
                            </tr>
                        <?php  endforeach; }?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- END EXAMPLE TABLE widget-->
            </div>
        </div>

        <!-- END ADVANCED TABLE widget-->
     </div>
      <p style="margin-left:30px;"><?php echo anchor('settings/add_deliverycharge', lang('add_delivery_charge'),'class="btn btn-lightred"')?> </p>
         <!-- END PAGE CONTAINER-->
 </div>