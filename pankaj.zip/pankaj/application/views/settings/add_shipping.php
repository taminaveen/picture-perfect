<script>
$(function(){
	$("#form1").validate({
		rules: {
                weight: "required",
                local: {
                    required: true,
                    number: true
                },               
                distance1: {
                    required: true,
                    number: true
                },
                distance2: {
                    required: true,
					number: true
                },
				distance3: {
                    required: true,
					number: true
                },
				distance4: {
                    required: true,
					number: true
                },
            },
            messages: {
                weight: "Please enter your dimention",                
                local: "Please enter numeric values only",                              
                distance1: "Please enter numeric values only",
				distance2: "Please enter numeric values only",
				distance3: "Please enter numeric values only",
				distance4: "Please enter numeric values only",
            }	
	});
});
</script>
<div id="main-content">
         <!-- BEGIN PAGE CONTAINER-->
     <div class="container-fluid">
        <!-- BEGIN PAGE HEADER-->   
        <div class="row-fluid">
           <div class="span12">
            	<?php if($message) { echo "<div class=\"alert alert-danger\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>
           </div>
        </div>
        <!-- END PAGE HEADER-->
        <!-- BEGIN ADVANCED TABLE widget-->
        <div class="row-fluid">
            <div class="span12">
            <!-- BEGIN EXAMPLE TABLE widget-->
            <div class="widget brown">
                <div class="widget-title">
                    <h4><i class="icon-plus-sign-alt"></i><?php echo $page_title; ?></h4>
                        <span class="tools">
                            <a href="javascript:;" class="icon-chevron-down"></a>
                            <a href="javascript:;" class="icon-remove"></a>
                        </span>
                </div>
                <div class="widget-body">
                <?php echo form_open("settings/add_deliverycharge",'class="form-horizontal cmxform" id="form1" ');?>
                
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('weight');?></label>
                        <div class="controls">
                            <?php echo form_input('weight', '', 'class="input-xlarge text-right" id="weight" ');?>
                        </div>
                    </div>
                    
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('local');?></label>
                        <div class="controls">
                            <?php echo form_input('local', '', 'class="input-xlarge text-right" id="local" ');?>
                        </div>
                    </div>
                    
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('upto200');?></label>
                        <div class="controls">
                            <?php echo form_input('distance1', '', 'class="input-xlarge text-right" id="distance1" ');?>
                        </div>
                    </div>
                    
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('201to1000');?></label>
                        <div class="controls">
                            <?php echo form_input('distance2', '', 'class="input-xlarge text-right" id="distance2" ');?>
                        </div>
                    </div>
                    
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('1001to2000');?></label>
                        <div class="controls">
                            <?php echo form_input('distance3', '', 'class="input-xlarge text-right" id="distance3" ');?>
                        </div>
                    </div>
                    
                    <div class="control-group">
                        <label class="control-label"><?php echo lang('above2000');?></label>
                        <div class="controls">
                            <?php echo form_input('distance4', '', 'class="input-xlarge text-right" id="distance4" ');?>
                        </div>
                    </div>
                    
                   <div class="form-actions">
                        <?php echo form_submit('submit', lang('add_delivery_charge'),'class="btn btn-primary"');?>
                    </div>
                    <?php echo form_close();?>
                </div>
            </div>
            <!-- END EXAMPLE TABLE widget-->
            </div>
        </div>

        <!-- END ADVANCED TABLE widget-->
     </div>
         <!-- END PAGE CONTAINER-->
      </div>
