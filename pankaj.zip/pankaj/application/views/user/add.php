<script>
$(function(){
	
	$("#addOrder_form").validate({
		rules: {
                title: "required",
                date: {
                    required: true,
                },               
				deldate: {
					required: true,
				},
            },
            messages: {
                title: "Please enter title for the print",                
                date: {
                    required: "Please select order date ",
                },
                deldate: {
                    required: "Please select delivery date",
                },                              
            }	
	});
});
$(function () {
	$("#dvSource img").draggable({
		revert: "invalid",
		refreshPositions: true,
		drag: function (event, ui) {
			ui.helper.addClass("draggable");
		},
		stop: function (event, ui) {
			ui.helper.removeClass("draggable");
			var image = this.src.split("/")[this.src.split("/").length - 1];
			if ($.ui.ddmanager.drop(ui.helper.data("draggable"), event)) {
				//alert(image + " dropped.");
				/*for(var i=0; i<len;i++)
				{
					if(i <= dlen)
					{
						$(wrap).append("<input type='text' name='dragndrop[]' value='"+image+"'>");
					}
				}*/
				//$("#dragndrop").val(image);
			}
			else {
				//alert(image + " not dropped.");
			}
		}
	});
	$("#dvDest").droppable({
		drop: function (event, ui) {
			if ($("#dvDest img").length == 0) {
				$("#dvDest").html("");
			}
			ui.draggable.addClass("dropped");
			$("#dvDest").append(ui.draggable);
			
			var image = ui.draggable.attr('src');
			var srcs ='', ans;
			$(".dragndrop1").each(function(i) {
				srcs = $(this).val();
				//ans = srcs+","+image;
			});
			//alert(check);
			if(srcs == "" || srcs == null)
			{
				ans = image;
				$(".dragndrop1").val(ans);
			}
			else
			{
				ans = srcs+","+image;
				$(".dragndrop1").val(ans);
			}
			
		}
	});
	
	$('#addRow').click(function(){
         var counter1 = $('.item-row').length;
         var counter = counter1+1;
         var content=  '<tr class="item-row" data-id="'+counter+'"><td id="label_'+counter+'">' + counter + '</td>'+
                            '<td><div id="dvDest'+counter+'" class="dvDest">Drop here</div><input type="hidden" name="dragndrop'+counter+'" id="dragndrop" class="dragndrop'+counter+'"></td>'+
							'<td><?php
									echo'<select name="dimension\' + counter + \'" id="dimension\' + counter + \'" class="chzn-select input-medium">';
									echo '<option value="">Select Dimension</option>';
									foreach ($dimensions as $dimension) {										
										echo "<option value=" . $dimension->id;        
        								echo ">" . $dimension->name . "</option>";
									}
									echo'</select>';
								?></td>'+
							'<td><label class="checkbox line"><input type="checkbox" name="printing'+counter+'" id="printype'+counter+'" value="printing" /> Printing</label><label class="checkbox line"><input type="checkbox" name="lamination'+counter+'" id="printype'+counter+'" value="lamination" /> Lamination</label><label class="checkbox line"><input type="checkbox" name="framing'+counter+'" id="printype'+counter+'" value="framing" /> Framing</label></td>'+		
							'<td><?php
									echo'<select name="cuaddress\' + counter + \'" id="cuaddress\' + counter + \'" class="chzn-select input-medium">';
									echo '<option value="">Select Address</option>';
									foreach ($addresses as $address) {										
										echo "<option value=" . $address->id;        
        								echo ">" . $address->title . "</option>";
									}
									echo'</select>';
								?></td>'+
                        	'<td><button type="button" class="btn btn-danger btn-sm delete"><i class="icon-trash"  aria-hidden="true"></i></button></td>'+
			'</tr>';
			
         $('#quTable:last').append(content);
		 
			$("#dvDest"+counter).droppable({
				
				drop: function (event, ui) {
					if ($("#dvDest"+counter+" img").length == 0) {
						$("#dvDest"+counter).html("");
					}
					
					ui.draggable.addClass("dropped");
					$("#dvDest"+counter).append(ui.draggable);
					var image = ui.draggable.attr('src');
					var srcs ='', ans;
					var check = $(".dragndrop"+counter).val();
					$(".dragndrop"+counter).each(function(i) {
                        srcs = $(this).val();
                    });
					//alert(check);
					if(check == "" || check == null)
					{
						ans = image;
					}
					else
					{
						ans = srcs+","+image;
					}
					$(".dragndrop"+counter).val(ans);
					
				}
		});	
    });
	$(document).on("click",".delete", function() {
    	$(this).parents('.item-row:last').remove();
  });
});

</script>
<style type="text/css">
	
	.pic
	{
		height: 100px;
		width: 100px;
		margin: 2px;
	}
	.draggable
	{
		filter: alpha(opacity=60);
		opacity: 0.6;
	}
	.dropped
	{
		position: static !important;
	}
	#dvSource
	{
		border: 5px solid #ccc;
		padding: 5px;
		min-height: 100px;
		width: 1000px;
		/*overflow:scroll;*/
	}
	#dvDest
	{
		border: 5px solid #ccc;
		padding: 5px;
		min-height: 100px;
		width: 400px;
		/*overflow:scroll;*/
	}
	.dvDest
	{
		border: 5px solid #ccc;
		padding: 5px;
		min-height: 100px;
		width: 400px;
	}
	#total
	{
		border: 5px solid #000000;
		padding: 3px;
		min-height: 20px;
		width: 200px;
		text-align:right;
		font-size:14px;
		font-weight:700;
		vertical-align:central;
	}
</style>
<div id="main-content">
         <!-- BEGIN PAGE CONTAINER-->
     <div class="container-fluid">
        <!-- BEGIN PAGE HEADER-->   
        <div class="row-fluid">
           <div class="span12">
            	<?php /*if($message) { echo "<div class=\"alert alert-danger\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>
                <?php if($success_message) { echo "<div class=\"alert alert-success\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $success_message . "</div>"; }*/ ?>
           </div>
        </div>
        <!-- END PAGE HEADER-->
        <!-- BEGIN ADVANCED TABLE widget-->
            <div class="row-fluid">
                <div class="span12">
                <!-- BEGIN EXAMPLE TABLE widget-->
                    <div class="widget orange">
                         <div class="widget-title">
                              <h4><i class="icon-reorder"></i><?php echo $page_title; ?></h4>
                               <span class="tools">
                               <a style="text-decoration:none;" class="btn btn-grey" data-toggle='modal' data-target='#myModal1' class='tip' title="Add Address">Add Address</a>
                                    <a class="icon-chevron-down" href="javascript:;"></a>
                                    <a class="icon-remove" href="javascript:;"></a>
                               </span>
                         </div>
                         <div class="widget-body">
                            <?php $attrib = array('class' => 'form-horizontal', 'id' => 'addOrder_form');
echo form_open("user/add_order", $attrib); ?>
                             <div class="span6">
                           		<div class="control-group">
                                    <label class="control-label">Print Title</label>
                                    <div class="controls">
                                        <input id="title" type="text" name="title" class="input-large">
                                    </div>
                                </div>
                                <div class="control-group">
                                    <label class="control-label">Date</label>
                                    <div class="controls">
                                        <input id="dp1" type="text" name="date" value="<?=date("d-m-Y")?>" size="16" class="input-large">
                                    </div>
                                </div>
                              </div>
                              <div class="span6">
                               	<div class="control-group">
                                    <label class="control-label">Amount</label>
                                    <div class="controls"> 
                                		<div id="total">0.00</div>
                                		<input type="hidden" name="amount" id="amount" />
                                    </div>
                                </div>
                             </div>
                             <div class="span12">
                                <div class="control-group">
                                   <div id="dvSource">
                                        <img class="pic" alt="" src="<?php echo base_url(); ?>theme/img/gallery/image1.jpg" />
                                        <img class="pic" alt="" src="<?php echo base_url(); ?>theme/img/gallery/image2.jpg" />
                                        <img class="pic" alt="" src="<?php echo base_url(); ?>theme/img/gallery/image3.jpg" />
                                        <img class="pic" alt="" src="<?php echo base_url(); ?>theme/img/gallery/image4.jpg" />
                                        <img class="pic" alt="" src="<?php echo base_url(); ?>theme/img/gallery/image5.jpg" />
                                        <img class="pic" alt="" src="<?php echo base_url(); ?>theme/img/gallery/image6.jpg" />
                                        <img class="pic" alt="" src="<?php echo base_url(); ?>theme/img/gallery/image7.jpg" />
                                        <img class="pic" alt="" src="<?php echo base_url(); ?>theme/img/gallery/image8.jpg" />
                                    </div>
                               </div>
                             </div>
                                <div class="control-group">
                                    <table id="quTable" class="table" >
                                        <tr class="item-row"  data-id="1">
                                            <td id="label_1">1</td>
                                            <td><div id="dvDest">Drop here</div><input type="hidden" name="dragndrop1" id="dragndrop" class="dragndrop1"></td>
                                             <td><?php
                                            $dms[""] = "Select Dimension";
                                            foreach ($dimensions as $dimension) {
                                                $dms[$dimension->id] = $dimension->name;
                                            }
                                            echo form_dropdown('dimension1', $dms, (isset($_POST['dimension1']) ? $_POST['dimension1'] : ''), 'id="dimension1" class="input-medium" ');
                                            ?></td>
                                           <!-- <td><?php
                                            $ds[""] = "";
                                            foreach ($deliveryfees as $deliveryfee) {
                                                $ds[$deliveryfee->id] = $deliveryfee->weight;
                                            }
                                            echo form_dropdown('deliveryfees1', $ds, (isset($_POST['deliveryfees1']) ? $_POST['deliveryfees1'] : ''), 'id="deliveryfees1" class="input-medium" ');
                                            ?></td>-->
                                            <td><label class="checkbox line"><input type="checkbox" name="printing1" id="printing1" value="printing" class="printype" /> Printing
                                        </label><label class="checkbox line"><input type="checkbox" name="lamination1" id="lamination1" value="lamination" class="printype" /> Lamination
                                        </label><label class="checkbox line"><input type="checkbox" name="framing1" id="framing1" value="framing" class="printype" /> Framing
                                        </label>                                            
                                       </td>
                                       <td><?php
                                            $ads[""] = "Select Address";
                                            foreach ($addresses as $address) {
                                                $ads[$address->id] = $address->title;
                                            }
                                            echo form_dropdown('cuaddress1', $ads, (isset($_POST['cuaddress1']) ? $_POST['cuaddress1'] : ''), 'id="cuaddress1" class="input-medium"  ');
                                            ?></td>
                                       <td></td>
                                        </tr> 
                                    </table>                                   
                                
                                        <div class="wrapper">
                                            <button type="button" id="addRow" class="addrow btn btn-lightred btn-sm">Add Row</button>
                                        </div>     
                                </div>  
                                 <div class="form-actions"> 
                                    <input type="submit" class="btn btn-large btn-success" value="Save">
                                 </div>
                           <?php echo form_close(); ?> 
                         </div>
                    </div>
                </div>
           </div>
     </div>
</div>

<script>
$(document).ready(function(e) {    
     $("#dp1").datepicker({
        format: "dd-mm-yyyy",
		autoclose: true,
    }).on('changeDate', function(ev){                 
    	$('#dp1').datepicker('hide');
	});
	
	$('#dimension1').change(function(event) {
		var sectionID = $(this).val();
		var classID = $(".printype:checked").serialize();
		
		if(sectionID === '0') {
			$('#dimension1').val(0);
		} else {
			$.ajax({
				type: 'POST',
				url: "<?php echo site_url('user/getdimensions'); ?>",
				data: classID+"&id="+sectionID,
				//$(".printype:checked").serialize(),
				//"id="+sectionID+"&clid="+ classID,
				dataType: "html",
				success: function(data) {
				   $('#total').html(data);
				   $('#amount').val(data);
				  //alert(data);
				}
			});
		}
	});
});
</script>
<div id="myModal1" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="myModalLabel1">More Delivery Addresses Add</h3>
    </div>
    <?php $attrib = array('class' => 'form-horizontal', 'id' => 'Updateform');
        echo form_open_multipart("user/add_address/", $attrib); ?>
    <div class="modal-body">
        <div class="control-group">
            <label class="control-label">Title</label>
            <div class="controls"> <?php echo form_input('title', (isset($_POST['title']) ? $_POST['title'] : ''), 'class="input-large" id="title" '); ?> </div>
        </div>
        <div class="control-group">
            <label class="control-label">Address</label>
            <div class="controls"> <?php echo form_input('address', (isset($_POST['address']) ? $_POST['address'] : ''), 'class="input-large" id="address" '); ?> </div>
        </div>
        <div class="control-group">
            <label class="control-label">City</label>
            <div class="controls"> <?php echo form_input('city', (isset($_POST['city']) ? $_POST['city'] : ''), 'class="input-large" id="city" '); ?> </div>
        </div>
        <div class="control-group">
            <label class="control-label">State</label>
            <div class="controls"> <?php echo form_input('state', (isset($_POST['state']) ? $_POST['state'] : ''), 'class="input-large" id="state" '); ?> </div>
        </div>
        <div class="control-group">
            <label class="control-label">Postal Code</label>
            <div class="controls"> <?php echo form_input('pincode', (isset($_POST['pincode']) ? $_POST['pincode'] : ''), 'class="input-large" id="pincode" '); ?> </div>
        </div>
    </div>
    <div class="modal-footer">
        <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
    </div>
    <?php echo form_close(); ?>
</div>