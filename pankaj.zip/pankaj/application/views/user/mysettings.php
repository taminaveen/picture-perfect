<div id="main-content">
         <!-- BEGIN PAGE CONTAINER-->
     <div class="container-fluid">
        <!-- BEGIN PAGE HEADER-->   
        <div class="row-fluid">
           <div class="span12">
            	<?php if($message) { echo "<div class=\"alert alert-danger\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>
                <?php if($success_message) { echo "<div class=\"alert alert-success\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $success_message . "</div>"; } ?>
           </div>
        </div>
        <!-- END PAGE HEADER-->
        <!-- BEGIN ADVANCED TABLE widget-->
        <div class="row-fluid">
            <div class="span12">
            <!-- BEGIN EXAMPLE TABLE widget-->
            <div class="widget purple">
                <div class="widget-title">
                    <h4><i class="icon-edit"></i><?php echo $page_title; ?></h4>
                        <span class="tools">
                            <a href="javascript:;" class="icon-chevron-down"></a>
                            <a href="javascript:;" class="icon-remove"></a>
                        </span>
                	</div>
                    <div class="widget-body form">
                    <?php echo form_open_multipart("user/change_picture/".$id,'class="form-horizontal" id="customerForm" ');?>
                    	<div class="control-group">
                             <label class="control-label">Change Image</label>
                             <div class="controls">
                                 <div data-provides="fileupload" class="fileupload fileupload-new">
                                     <div style="width: 200px; height: 150px;" class="fileupload-new thumbnail">
                                     <?php if(USER_IMAGE == NULL || USER_IMAGE == ''){?>
                                         <img alt="" src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image">
                                     <?php } else { ?>
                                     	 <img alt="" src="<?php echo base_url(); ?>theme/uploads/images/<?=USER_IMAGE?>">
                                     <?php } ?>
                                     </div>
                                     <div style="max-width: 200px; max-height: 150px; line-height: 20px;" class="fileupload-preview fileupload-exists thumbnail"></div>
                                     <div>
                                        <span class="btn btn-file"><span class="fileupload-new">Select image</span>
                                        <span class="fileupload-exists">Change</span>
                                        <input type="file" name="userfile" id="user_image" class="default"></span>
                                        <a data-dismiss="fileupload" class="btn fileupload-exists" href="#">Remove</a>
                                     </div>
                                 </div>
                             </div>
                         </div>
                         <div class="form-actions"> 
                         	<input type="submit" class="btn btn-large btn-grey" value="Save">
                         </div>
                     <?php echo form_close();?>
    				</div>                
         		</div>
        	</div>
     	</div>
  	</div>
</div>



                                             
