<div id="main-content">
         <!-- BEGIN PAGE CONTAINER-->
     <div class="container-fluid">
        <!-- BEGIN PAGE HEADER-->   
        <div class="row-fluid">
           <div class="span12">
            	<?php if($message) { echo "<div class=\"alert alert-danger\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>
           </div>
        </div>
        <!-- END PAGE HEADER-->
        <!-- BEGIN ADVANCED TABLE widget-->
        <div class="row-fluid">
            <div class="span12">
            <!-- BEGIN EXAMPLE TABLE widget-->
            <div class="widget purple">
                <div class="widget-title">
                    <h4><i class="icon-edit"></i><?php echo $page_title; ?></h4>
                        <span class="tools">
                            <a href="javascript:;" class="icon-chevron-down"></a>
                            <a href="javascript:;" class="icon-remove"></a>
                        </span>
                	</div>
                    <div class="widget-body">
                <?php echo form_open("admin/users/save_details/",'class="form-horizontal" id="customerForm" ');?>
         <input type="hidden" name="id" value="<?php echo set_value('id',isset($item['id']) ? $item['id'] : ''); ?>" />
         <div class="control-group">
            <label class="control-label">Name</label>
            <div class="controls">   
            <input type="text" class="input-large" name="name" maxlength="255" placeholder="Full Name" value="<?php echo set_value('name',isset($item['name']) ? $item['name'] : ''); ?>" autofocus></div>
            <?php echo form_error('name'); ?>
          </div>                           
          <div class="control-group"> 
            <label class="control-label">Email</label>  
            <div class="controls"><input type="email" class="input-large" name="email" placeholder="Email Address" value="<?php echo set_value('email',isset($item['email']) ? $item['email'] : ''); ?>"></div>
            <?php echo form_error('email'); ?>
          </div>
          <div class="control-group">  
            <label class="control-label">Username</label> 
            <div class="controls"><input type="text" class="input-large" name="username" maxlength="32" placeholder="Username" value="<?php echo set_value('username',isset($item['username']) ? $item['username'] : ''); ?>"></div>
            <?php echo form_error('username'); ?>
          </div>
          <div class="control-group">    
            <label class="control-label">Password</label>
            <div class="controls"><input type="password" class="input-large" name="password" id="password" maxlength="32" placeholder="Password">      </div>               
            <?php echo form_error('password'); ?>
          </div>
         <div class="control-group">  
            <label class="control-label">Confirm Password</label>  
            <div class="controls"><input type="password" class="input-large" name="confirm_password" maxlength="32" placeholder="Confirm Password"></div>
            <?php echo form_error('confirm_password'); ?>
          </div>                 
          <div id="pwd-container">
            <div class="pwstrength_viewport_progress"></div>
          </div>         
           <div class="control-group">  
              <label class="control-label">Birthday</label>
              <div class="controls span3"> <?php $options = array('01'=>'January','02'=>'February','03'=>'March','04'=>'April','05'=>'May','06'=>'June','07'=>'July','08'=>'August','09'=>'September','10'=>'October','11'=>'November','12'=>'December');?>
              <?php echo form_dropdown('month', $options, set_value('month',isset($item['month']) ? $item['month'] : ''), 'class="chzn-select"'); ?> 
              <?php echo form_error('month'); ?>
            </div>
            <div class="controls span2">
              <input type="number" class="input-mini" name="day" maxlength="2" min="1" max="31" placeholder="Day" value="<?php echo set_value('day',isset($item['day']) ? $item['day'] : ''); ?>">
              <?php echo form_error('day'); ?>
            </div>
           <div class="controls span2"> 
              <input type="number" class="input-mini" name="year" maxlength="4" size="4" placeholder="Year" value="<?php echo set_value('year',isset($item['year']) ? $item['year'] : ''); ?>">
              <?php echo form_error('year'); ?>
            </div>
          </div>           
          <div class="control-group">  
            <label class="control-label">Gender</label>  
            <?php $options = array('male'=>'Male','female'=>'Female','other'=>'Other');?>
            <div class="controls"><?php echo form_dropdown('gender', $options, set_value('gender',isset($item['gender']) ? $item['gender'] : ''), 'class="chzn-select"'); ?></div>
            <?php echo form_error('gender'); ?>
          </div>
          <div class="control-group"> 
            <label class="control-label">Mobile phone</label>  
            <div class="controls"><input type="tel" class="form-control form-control-sm" name="mobile_no" maxlength="15" placeholder="Mobile no" value="<?php echo set_value('mobile_no',isset($item['mobile_no']) ? $item['mobile_no'] : ''); ?>"></div>
            <?php echo form_error('mobile_no'); ?>
          </div>
          <div class="control-group">
            <label class="control-label">Location</label>
            <?php 
            $result = $this->db->get('countries')->result();
            $options = array();
            foreach($result as $row){
                $options[$row->id] = $row->name;
            }
            ?>                
            <div class="controls"><?php echo form_dropdown('location', $options, set_value('location',isset($item['location']) ? $item['location'] : ''), 'class="chzn-select"'); ?>   </div>              
            <?php echo form_error('location'); ?>
          </div>
                                      
           <div class="form-actions"> <input type="submit" class="btn btn-sm btn-success" value="Save Details">
            <?php if(!isset($item['id'])): ?>
            <input type="reset" class="btn btn-sm btn-primary" value="Reset">          
            <?php endif; ?>
            <a class="btn btn-sm btn-warning" href="<?php echo site_url().'user/index'; ?>">Close</a>
            </div>
        <div class="clearfix"></div>
      <?php echo form_close();?>
    </div>                
         		</div>
        	</div>
     	</div>
  	</div>
</div>