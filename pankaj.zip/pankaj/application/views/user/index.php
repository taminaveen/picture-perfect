<script>
$(document).ready(function() {
	 $('#sample_1').dataTable({
		"sDom": 'T<"clear">lfrtip',	
		/*buttons: [
            {
                extend: 'print',
                customize: function ( win ) {
                    $(win.document.body)
                        .css( 'font-size', '10pt' );                       
 
                    $(win.document.body).find( 'table' )
                        .addClass( 'compact' )
                        .css( 'font-size', 'inherit' );
                }
            }
        ]	*/
		"sPaginationType": "bootstrap",
		"oLanguage": {
			"sLengthMenu": "_MENU_ records per page",
			"oPaginate": {
				"sPrevious": "Prev",
				"sNext": "Next"
			}
		},
		"oTableTools": {
			"sSwfPath": "<?php echo base_url(); ?>theme/assets/data-tables/swf/copy_csv_xls_pdf.swf",
			"aButtons": [
							{
								"sExtends": "csv",
								"sFileName": "customers.csv",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
							{
								"sExtends": "xls",
								"sFileName": "customers.xls",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
							{
								"sExtends": "pdf",
								"sFileName": "customers.pdf",
								"sPdfOrientation": "landscape",
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},
							{
								"sExtends": "print",								
								"mColumns": [ 0, 1, 2, 3, 4, 5]
							},						
					],
			
		},
		//"aoColumns": [null, null, null, null, null null,null]
	/*	"aoColumnDefs": [{
			    'bSortable': false,
                "aTargets": [0],
                "aoColumns": [null, null, null, null, null null,null]
            }]*/
		/*"aoColumnDefs": [null, null,{
			'bSortable': false,
			'aTargets': [2],
			'mRender':format_date
		}, null, null null, null],*/
		 //"aoColumnDefs": [ {"bSortable": false, "aTargets": [0]} ]
	});

	$('#sample_1_wrapper .dataTables_filter input').addClass("input-medium"); // modify table search input
	$('#sample_1_wrapper .dataTables_length select').addClass("input-mini"); // modify table per page dropdown
});
</script>

<div id="main-content">
         <!-- BEGIN PAGE CONTAINER-->
     <div class="container-fluid">
        <!-- BEGIN PAGE HEADER-->   
        <div class="row-fluid">
           <div class="span12">
            	<?php if($message) { echo "<div class=\"alert alert-danger\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>
<?php if($success_message) { echo "<div class=\"alert alert-success\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $success_message . "</div>"; } ?>
           </div>
        </div>
        <!-- END PAGE HEADER-->
        <!-- BEGIN ADVANCED TABLE widget-->
        <div class="row-fluid">
            <div class="span12">
            <!-- BEGIN EXAMPLE TABLE widget-->
            <div class="widget red">
                <div class="widget-title">
                    <h4><i class="icon-list"></i><?php echo $page_title; ?></h4>
                        <span class="tools">
                            <a href="javascript:;" class="icon-chevron-down"></a>
                            <a href="javascript:;" class="icon-remove"></a>
                        </span>
                </div>
                <div class="widget-body">
                    <table class="table table-striped table-bordered" id="sample_1">
                        <thead>
                        <tr>
                            <th><?php echo lang('name');?></th>
                            <th><?php echo lang('username');?></th>
                            <th><?php echo lang('dob');?></th>
                            <th><?php echo lang('gender');?></th>
                            <th><?php echo lang('email');?></th>
                            <th><?php echo lang('phone');?></th>
                            <th><?php echo lang('actions');?></th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($customers as $customer): ?>
                            <tr class="odd gradeX">
                                <td><?php echo $customer->name;?></td>
                                <td><?php echo $customer->username;?></td>
                                <td><?php echo $customer->birth_date;?></td>
                                <td><?php echo $customer->gender; ?>  </td>
                                <td><?php echo $customer->email; ?>  </td>
                                <td><?php echo $customer->mobile_no;?></td>
                                <td><?php echo anchor("admin/users/edit_details/".$customer->id, 'Edit') ;?></td>
                            </tr>
                        <?php  endforeach;?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- END EXAMPLE TABLE widget-->
            </div>
        </div>

        <!-- END ADVANCED TABLE widget-->
     </div>
     
         <!-- END PAGE CONTAINER-->
 </div>

      


      
