<script>
$(function(){
	$("#customerForm").validate({
		rules: {
                old_password: "required",
                new_password: {
                    required: true,
                },               
				conf_password: {
					required: true,
					equalTo: "#new_password"
				},
            },
            messages: {
                old_password: "Please enter a old Password",                
                new_password: {
                    required: "Please provide a new password",
                },
                conf_password: {
                    required: "Please provide a confirm new password",
                    equalTo: "Please enter the same password as above"
                },                              
            }	
	});
});
</script>
<div id="main-content">
         <!-- BEGIN PAGE CONTAINER-->
     <div class="container-fluid">
        <!-- BEGIN PAGE HEADER-->   
        <div class="row-fluid">
           <div class="span12">
            	<?php if($message) { echo "<div class=\"alert alert-danger\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $message . "</div>"; } ?>
                <?php if($success_message) { echo "<div class=\"alert alert-success\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $success_message . "</div>"; } ?>
           </div>
        </div>
        <!-- END PAGE HEADER-->
        <!-- BEGIN ADVANCED TABLE widget-->
        <div class="row-fluid">
            <div class="span12">
            <!-- BEGIN EXAMPLE TABLE widget-->
            
                <div class="widget orange">
                     <div class="widget-title">
                          <h4><i class="icon-reorder"></i><?php echo $page_title; ?></h4>
                           <span class="tools">
                                <a class="icon-chevron-down" href="javascript:;"></a>
                                <a class="icon-remove" href="javascript:;"></a>
                           </span>
                     </div>
                     <div class="widget-body ">
                         <?php echo form_open_multipart("user/change_password/",'class="form-horizontal" id="customerForm" ');?>
                             <div class="control-group">
                                 <label class="control-label">Current Password</label>
                                 <div class="controls">
                                     <input type="password" class="span4" id="old_password" name="old_password" placeholder="Old Password">
                                 </div>
                             </div>
                             <div class="control-group">
                                 <label class="control-label">New Password</label>
                                 <div class="controls">
                                     <input type="password" class="span4" id="new_password" name="new_password" placeholder="New Password">
                                 </div>
                             </div>
                             <div class="control-group">
                                 <label class="control-label">Re-type New Password</label>
                                 <div class="controls">
                                     <input type="password" class="span4" id="conf_password" name="conf_password" placeholder="Re-type New Password">
                                 </div>
                             </div>

                             <div class="form-actions">
                                 <button type="submit" class="btn btn-success">Change Password</button>
                                 <button type="button" class="btn">Cancel</button>
                             </div>

                         <?php echo form_close();?>
                     </div>
            	</div>
        	</div>
     	</div>
  	</div>
</div>



                                             
