<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container-fluid">
	<!-- BEGIN HEADER -->
	<header id="page-title" class="row">
		<div class="col-md-12">
			<h1><span class="glyphicon glyphicon-picture"></span> Media Manager</h1>
		</div>
	</header>
	<!-- END HEADER -->
	<div class="container">
		<div class="row">			
			<article>
				<div class="col-md-12 pages">
					<h2 class="text-center">Privacy Policy</h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc facilisis tellus vitae interdum facilisis. 
					Morbi sed mauris et magna laoreet tempor. Nulla aliquet neque leo, in gravida ipsum vehicula nec. Lorem ipsum dolor 
					sit amet, consectetur adipiscing elit. Duis efficitur ultrices velit, eget volutpat risus hendrerit sed. Aenean 
					elementum sed justo sit amet tristique. Ut nec congue ante, in mattis dui. Integer ultricies vestibulum pulvinar. 
					Curabitur quis dolor sagittis, tincidunt ipsum eget, pharetra diam. Praesent turpis elit, suscipit vitae odio ut, 
					ultrices efficitur odio. Integer lacinia congue nisl a bibendum. Vivamus condimentum augue id rutrum faucibus. 
					Fusce mollis blandit tempus. Curabitur eu rhoncus diam. Vestibulum a ullamcorper dui, sed sollicitudin ex.<br>
					Aliquam erat volutpat. Proin feugiat porttitor tellus, vel fermentum enim auctor eget. Suspendisse mauris arcu, 
					aliquet id risus at, tincidunt malesuada est. Cras vel placerat lectus, ac feugiat nisl. Phasellus posuere tellus ac 
					augue finibus, sodales cursus sapien molestie. Proin malesuada congue luctus. Proin consectetur felis augue. Nam non 
					quam sit amet est tincidunt bibendum id at urna. Curabitur id consequat sapien. Nunc scelerisque vitae arcu ac faucibus. 
					Cras rutrum posuere lorem et egestas.<br>
					Interdum et malesuada fames ac ante ipsum primis in faucibus. Duis scelerisque finibus sem blandit pharetra. Integer massa 
					felis, facilisis at libero at, tincidunt scelerisque leo. Vestibulum viverra risus risus, a rhoncus libero tristique sed. 
					Nulla facilisi. Donec condimentum quam sit amet viverra pharetra. Quisque eget hendrerit orci. Cras sem turpis, tristique 
					nec mattis sit amet, venenatis vel elit. Pellentesque at neque sit amet risus posuere efficitur eget sed velit. Suspendisse 
					fringilla rutrum facilisis. Suspendisse vehicula nisi eget consequat aliquet.<br>
					Vestibulum finibus ut velit non viverra. Duis volutpat id nibh et dictum. Vestibulum dignissim quam vel elit volutpat, 
					sit amet aliquam arcu facilisis. Sed tristique erat lectus, et sodales justo porttitor quis. Etiam ultrices feugiat 
					elementum. In hac habitasse platea dictumst. Suspendisse potenti.<br>
					Sed vel aliquam risus, pharetra interdum tellus. Curabitur accumsan mi quam, at accumsan nisi auctor quis. Cras sodales 
					velit ut tellus vehicula bibendum sit amet ac nunc. Etiam id maximus mi. Suspendisse posuere pulvinar ligula, non posuere 
					lacus. Suspendisse imperdiet at nulla non dapibus. Nullam quam dolor, ullamcorper non tincidunt eget, viverra laoreet dolor. 
					Sed blandit dolor non orci porttitor aliquam. Nullam molestie mi eget ultricies tincidunt. Sed dapibus nibh ac tortor pulvinar 
					eleifend. Curabitur lacinia porta placerat. Fusce venenatis ligula a arcu molestie egestas. Proin dui eros, malesuada ac erat 
					vel, condimentum tempus ex.
					</p>
				</div>
			</article>		
		</div>
	</div>
</div>  