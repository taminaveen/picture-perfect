-- phpMyAdmin SQL Dump
-- version 4.6.5.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 09, 2017 at 08:45 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pictureperfect`
--

-- --------------------------------------------------------

--
-- Table structure for table `autologin`
--

CREATE TABLE `autologin` (
  `user` int(11) NOT NULL,
  `series` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(5) NOT NULL,
  `name` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`) VALUES
(1, 'Afghanistan (‫افغانستان‬‎)'),
(2, 'Åland Islands (Åland)'),
(3, 'Albania (Shqipëria)'),
(4, 'Algeria (‫الجزائر‬‎)'),
(5, 'American Samoa'),
(6, 'Andorra'),
(7, 'Angola'),
(8, 'Anguilla'),
(9, 'Antarctica'),
(10, 'Antigua and Barbuda'),
(11, 'Argentina'),
(12, 'Armenia (Հայաստան)'),
(13, 'Aruba'),
(14, 'Ascension Island'),
(15, 'Australia'),
(16, 'Austria (Österreich)'),
(17, 'Azerbaijan (Azərbaycan)'),
(18, 'Bahamas'),
(19, 'Bahrain (‫البحرين‬‎)'),
(20, 'Bangladesh (বাংলাদেশ)'),
(21, 'Barbados'),
(22, 'Belarus (Беларусь)'),
(23, 'Belgium (België)'),
(24, 'Belize'),
(25, 'Benin (Bénin)'),
(26, 'Bermuda'),
(27, 'Bhutan (འབྲུག)'),
(28, 'Bolivia'),
(29, 'Bosnia and Herzegovina (Босна и Херцеговина)'),
(30, 'Botswana'),
(31, 'Bouvet Island'),
(32, 'Brazil (Brasil)'),
(33, 'British Indian Ocean Territory'),
(34, 'British Virgin Islands'),
(35, 'Brunei'),
(36, 'Bulgaria (България)'),
(37, 'Burkina Faso'),
(38, 'Burundi (Uburundi)'),
(39, 'Cambodia (កម្ពុជា)'),
(40, 'Cameroon (Cameroun)'),
(41, 'Canada'),
(42, 'Canary Islands (Islas Canarias)'),
(43, 'Cape Verde (Kabu Verdi)'),
(44, 'Caribbean Netherlands'),
(45, 'Cayman Islands'),
(46, 'Central African Republic (République centrafricaine)'),
(47, 'Ceuta and Melilla (Ceuta y Melilla)'),
(48, 'Chad (Tchad)'),
(49, 'Chile'),
(50, 'China (中国)'),
(51, 'Christmas Island'),
(52, 'Clipperton Island (Île Clipperton)'),
(53, 'Cocos [Keeling] Islands'),
(54, 'Colombia'),
(55, 'Comoros (‫جزر القمر‬‎)'),
(56, 'Congo [DRC] (Jamhuri ya Kidemokrasia ya Kongo)'),
(57, 'Congo [Republic] (Congo-Brazzaville)'),
(58, 'Cook Islands'),
(59, 'Costa Rica'),
(60, 'Côte d’Ivoire'),
(61, 'Croatia (Hrvatska)'),
(62, 'Cuba'),
(63, 'Curaçao'),
(64, 'Cyprus (Κύπρος)'),
(65, 'Czech Republic (Česká republika)'),
(66, 'Denmark (Danmark)'),
(67, 'Diego Garcia'),
(68, 'Djibouti'),
(69, 'Dominica'),
(70, 'Dominican Republic (República Dominicana)'),
(71, 'Ecuador'),
(72, 'Egypt (‫مصر‬‎)'),
(73, 'El Salvador'),
(74, 'Equatorial Guinea (Guinea Ecuatorial)'),
(75, 'Eritrea'),
(76, 'Estonia (Eesti)'),
(77, 'Ethiopia'),
(78, 'Falkland Islands [Islas Malvinas]'),
(79, 'Faroe Islands (Føroyar)'),
(80, 'Fiji'),
(81, 'Finland (Suomi)'),
(82, 'France'),
(83, 'French Guiana (Guyane française)'),
(84, 'French Polynesia (Polynésie française)'),
(85, 'French Southern Territories (Terres australes françaises)'),
(86, 'Gabon'),
(87, 'Gambia'),
(88, 'Georgia (საქართველო)'),
(89, 'Germany (Deutschland)'),
(90, 'Ghana (Gaana)'),
(91, 'Gibraltar'),
(92, 'Greece (Ελλάδα)'),
(93, 'Greenland (Kalaallit Nunaat)'),
(94, 'Grenada'),
(95, 'Guadeloupe'),
(96, 'Guam'),
(97, 'Guatemala'),
(98, 'Guernsey'),
(99, 'Guinea (Guinée)'),
(100, 'Guinea-Bissau (Guiné Bissau)'),
(101, 'Guyana'),
(102, 'Haiti'),
(103, 'Heard Island and McDonald Islands'),
(104, 'Honduras'),
(105, 'Hong Kong (香港)'),
(106, 'Hungary (Magyarország)'),
(107, 'Iceland (Ísland)'),
(108, 'India (भारत)'),
(109, 'Indonesia'),
(110, 'Iran (‫ایران‬‎)'),
(111, 'Iraq (‫العراق‬‎)'),
(112, 'Ireland'),
(113, 'Isle of Man'),
(114, 'Israel (‫ישראל‬‎)'),
(115, 'Italy (Italia)'),
(116, 'Jamaica'),
(117, 'Japan (日本)'),
(118, 'Jersey'),
(119, 'Jordan (‫الأردن‬‎)'),
(120, 'Kazakhstan (Казахстан)'),
(121, 'Kenya'),
(122, 'Kiribati'),
(123, 'Kosovo (Косово)'),
(124, 'Kuwait (‫الكويت‬‎)'),
(125, 'Kyrgyzstan'),
(126, 'Laos (ສ.ປ.ປ ລາວ)'),
(127, 'Latvia (Latvija)'),
(128, 'Lebanon (‫لبنان‬‎)'),
(129, 'Lesotho'),
(130, 'Liberia'),
(131, 'Libya (‫ليبيا‬‎)'),
(132, 'Liechtenstein'),
(133, 'Lithuania (Lietuva)'),
(134, 'Luxembourg'),
(135, 'Macau (澳門)'),
(136, 'Macedonia [FYROM] (Македонија)'),
(137, 'Madagascar (Madagasikara)'),
(138, 'Malawi'),
(139, 'Malaysia'),
(140, 'Maldives'),
(141, 'Mali'),
(142, 'Malta'),
(143, 'Marshall Islands'),
(144, 'Martinique'),
(145, 'Mauritania (‫موريتانيا‬‎)'),
(146, 'Mauritius (Moris)'),
(147, 'Mayotte'),
(148, 'Mexico (México)'),
(149, 'Micronesia'),
(150, 'Moldova (Republica Moldova)'),
(151, 'Monaco'),
(152, 'Mongolia (Монгол)'),
(153, 'Montenegro (Crna Gora)'),
(154, 'Montserrat'),
(155, 'Morocco (‫المغرب‬‎)'),
(156, 'Mozambique (Moçambique)'),
(157, 'Myanmar [Burma] (မြန်မာ)'),
(158, 'Namibia'),
(159, 'Nauru'),
(160, 'Nepal (नेपाल)'),
(161, 'Netherlands (Nederland)'),
(162, 'New Caledonia (Nouvelle-Calédonie)'),
(163, 'New Zealand'),
(164, 'Nicaragua'),
(165, 'Niger (Nijar)'),
(166, 'Nigeria'),
(167, 'Niue'),
(168, 'Norfolk Island'),
(169, 'Northern Mariana Islands'),
(170, 'North Korea (조선 민주주의 인민 공화국)'),
(171, 'Norway (Norge)'),
(172, 'Oman (‫عُمان‬‎)'),
(173, 'Pakistan (‫پاکستان‬‎)'),
(174, 'Palau'),
(175, 'Palestine (‫فلسطين‬‎)'),
(176, 'Panama (Panamá)'),
(177, 'Papua New Guinea'),
(178, 'Paraguay'),
(179, 'Peru (Perú)'),
(180, 'Philippines'),
(181, 'Pitcairn Islands'),
(182, 'Poland (Polska)'),
(183, 'Portugal'),
(184, 'Puerto Rico'),
(185, 'Qatar (‫قطر‬‎)'),
(186, 'Réunion'),
(187, 'Romania (România)'),
(188, 'Russia (Россия)'),
(189, 'Rwanda'),
(190, 'Saint Barthélemy (Saint-Barthélémy)'),
(191, 'Saint Helena'),
(192, 'Saint Kitts and Nevis'),
(193, 'Saint Lucia'),
(194, 'Saint Martin (Saint-Martin [partie française])'),
(195, 'Saint Pierre and Miquelon (Saint-Pierre-et-Miquelon)'),
(196, 'Saint Vincent and the Grenadines'),
(197, 'Samoa'),
(198, 'San Marino'),
(199, 'São Tomé and Príncipe (São Tomé e Príncipe)'),
(200, 'Saudi Arabia (‫المملكة العربية السعودية‬‎)'),
(201, 'Senegal (Sénégal)'),
(202, 'Serbia (Србија)'),
(203, 'Seychelles'),
(204, 'Sierra Leone'),
(205, 'Singapore'),
(206, 'Sint Maarten'),
(207, 'Slovakia (Slovensko)'),
(208, 'Slovenia (Slovenija)'),
(209, 'Solomon Islands'),
(210, 'Somalia (Soomaaliya)'),
(211, 'South Africa'),
(212, 'South Georgia and the South Sandwich Islands'),
(213, 'South Korea (대한민국)'),
(214, 'South Sudan (‫جنوب السودان‬‎)'),
(215, 'Spain (España)'),
(216, 'Sri Lanka (ශ්‍රී ලංකාව)'),
(217, 'Sudan (‫السودان‬‎)'),
(218, 'Suriname'),
(219, 'Svalbard and Jan Mayen (Svalbard og Jan Mayen)'),
(220, 'Swaziland'),
(221, 'Sweden (Sverige)'),
(222, 'Switzerland (Schweiz)'),
(223, 'Syria (‫سوريا‬‎)'),
(224, 'Taiwan (台灣)'),
(225, 'Tajikistan'),
(226, 'Tanzania'),
(227, 'Thailand (ไทย)'),
(228, 'Timor-Leste'),
(229, 'Togo'),
(230, 'Tokelau'),
(231, 'Tonga'),
(232, 'Trinidad and Tobago'),
(233, 'Tristan da Cunha'),
(234, 'Tunisia (‫تونس‬‎)'),
(235, 'Turkey (Türkiye)'),
(236, 'Turkmenistan'),
(237, 'Turks and Caicos Islands'),
(238, 'Tuvalu'),
(239, 'U.S. Outlying Islands'),
(240, 'U.S. Virgin Islands'),
(241, 'Uganda'),
(242, 'Ukraine (Україна)'),
(243, 'United Arab Emirates (‫الإمارات العربية المتحدة‬‎)'),
(244, 'United Kingdom'),
(245, 'United States'),
(246, 'Uruguay'),
(247, 'Uzbekistan (Ўзбекистон)'),
(248, 'Vanuatu'),
(249, 'Vatican City (Città del Vaticano)'),
(250, 'Venezuela'),
(251, 'Vietnam (Việt Nam)'),
(252, 'Wallis and Futuna'),
(253, 'Western Sahara (‫الصحراء الغربية‬‎)'),
(254, 'Yemen (‫اليمن‬‎)'),
(255, 'Zambia'),
(256, 'Zimbabwe');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `surname` varchar(80) DEFAULT NULL,
  `username` varchar(32) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `birth_date` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `mobile_no` varchar(15) NOT NULL,
  `location` smallint(3) NOT NULL,
  `image` varchar(60) DEFAULT NULL,
  `register_date` datetime NOT NULL,
  `last_visit_date` datetime NOT NULL,
  `usertype` tinyint(2) NOT NULL,
  `activation` varchar(32) NOT NULL,
  `access` varchar(10) NOT NULL DEFAULT 'Private'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `surname`, `username`, `email`, `password`, `birth_date`, `gender`, `phone`, `mobile_no`, `location`, `image`, `register_date`, `last_visit_date`, `usertype`, `activation`, `access`) VALUES
(1, 'Naveen', '', 'tamilnaveen', 'naveen@gmail.com', 'd4abed23978ea74dde73beaa6a2b7d15:9ZdOf59Akd3cJAtfLTZ50QA0mLF5Ctmc', '1989-10-05', 'male', '', '9942025157', 108, NULL, '2017-03-27 13:03:24', '2017-05-08 18:05:27', 0, '1', 'Private'),
(2, 'Sundar', 'june', 'sundarjune', 'sundar@gmail.com', 'a8b5034fc711f0bc51c01de174e81554:8WrXLKjzSAxmlPfTPcCv6K3g1gFmdgKh', '1990-11-15', 'male', '22775544', '9966330022', 108, 'Admin-icon.png', '2017-04-26 17:04:22', '2017-04-27 17:04:53', 0, '1RPQWkpJv08bFpo8EnBCnNTd2pWqY8K8', 'Private');

-- --------------------------------------------------------

--
-- Table structure for table `customer_addresses`
--

CREATE TABLE `customer_addresses` (
  `id` int(100) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(60) NOT NULL,
  `state` varchar(50) NOT NULL,
  `pincode` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer_addresses`
--

INSERT INTO `customer_addresses` (`id`, `customer_id`, `title`, `address`, `city`, `state`, `pincode`) VALUES
(1, 1, 'Home', '10,Anna nagar west,', 'Chennai', 'Tamilnadu', 600025),
(2, 1, 'Office', 'ggfdgfdg', 'Bangalore', 'Karnataka', 560109);

-- --------------------------------------------------------

--
-- Table structure for table `date_format`
--

CREATE TABLE `date_format` (
  `id` int(11) NOT NULL,
  `js` varchar(20) NOT NULL,
  `php` varchar(20) NOT NULL,
  `sql` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `date_format`
--

INSERT INTO `date_format` (`id`, `js`, `php`, `sql`) VALUES
(1, 'mm-dd-yyyy', 'm-d-Y', '%m-%d-%Y'),
(2, 'mm/dd/yyyy', 'm/d/Y', '%m/%d/%Y'),
(3, 'dd-mm-yyyy', 'd-m-Y', '%d-%m-%Y'),
(4, 'dd/mm/yyyy', 'd/m/Y', '%d/%m/%Y');

-- --------------------------------------------------------

--
-- Table structure for table `deliveryfees`
--

CREATE TABLE `deliveryfees` (
  `id` int(20) NOT NULL,
  `weight` varchar(60) NOT NULL,
  `local` decimal(25,2) NOT NULL,
  `d1` decimal(25,2) NOT NULL,
  `d2` decimal(25,2) NOT NULL,
  `d3` decimal(25,2) NOT NULL,
  `d4` decimal(25,2) NOT NULL,
  `status` int(5) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `deliveryfees`
--

INSERT INTO `deliveryfees` (`id`, `weight`, `local`, `d1`, `d2`, `d3`, `d4`, `status`) VALUES
(1, 'upto 50 gms', '15.00', '35.00', '35.00', '35.00', '35.00', 1),
(2, '51 gms to 200 gms', '25.00', '35.00', '40.00', '60.00', '70.00', 1),
(3, '201 gms to 500 gms', '30.00', '50.00', '60.00', '80.00', '90.00', 1),
(4, 'Additional 500 gms', '10.00', '15.00', '30.00', '40.00', '50.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `dimensions`
--

CREATE TABLE `dimensions` (
  `id` int(150) NOT NULL,
  `name` varchar(80) NOT NULL,
  `printing` decimal(25,2) NOT NULL,
  `lamination` decimal(25,2) NOT NULL,
  `framing` decimal(25,2) NOT NULL,
  `status` int(5) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dimensions`
--

INSERT INTO `dimensions` (`id`, `name`, `printing`, `lamination`, `framing`, `status`) VALUES
(1, '4x6', '5.00', '25.00', '100.00', 1),
(2, '5x7', '15.00', '25.00', '135.00', 1),
(3, '6x8', '20.00', '50.00', '150.00', 1),
(4, '6x9', '25.00', '75.00', '170.00', 1),
(5, '8x10', '60.00', '100.00', '250.00', 1),
(6, '8x12', '75.00', '100.00', '300.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `discounts`
--

CREATE TABLE `discounts` (
  `id` int(11) NOT NULL,
  `name` varchar(55) NOT NULL,
  `discount` decimal(8,2) NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `discounts`
--

INSERT INTO `discounts` (`id`, `name`, `discount`, `type`) VALUES
(1, 'No Discount', '0.00', '2'),
(2, '2.5 Percent', '2.50', '1'),
(3, '5 Percent', '5.00', '1'),
(4, '10 Percent', '10.00', '1'),
(5, 'Concession', '500.00', '2');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'operator', 'Operator'),
(3, 'user', 'View User');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `raw_name` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_ext` varchar(20) NOT NULL,
  `file_size` varchar(20) NOT NULL,
  `is_image` tinyint(1) NOT NULL,
  `image_width` smallint(5) UNSIGNED DEFAULT NULL,
  `image_height` smallint(5) UNSIGNED DEFAULT NULL,
  `image_type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `user_id`, `raw_name`, `file_name`, `file_type`, `file_path`, `file_ext`, `file_size`, `is_image`, `image_width`, `image_height`, `image_type`) VALUES
(1, 1, 'apps', 'apps.png', 'image/png', '/', '.png', '85.24', 1, 300, 300, 'png');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(150) NOT NULL,
  `order_id` int(11) NOT NULL,
  `pictures` text NOT NULL,
  `address` text NOT NULL,
  `printtypes` varchar(100) DEFAULT NULL,
  `printing` decimal(25,2) NOT NULL,
  `lamination` decimal(25,2) NOT NULL,
  `framing` decimal(25,2) NOT NULL,
  `total` decimal(25,2) NOT NULL,
  `status` int(5) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `pictures`, `address`, `printtypes`, `printing`, `lamination`, `framing`, `total`, `status`) VALUES
(1, 1, 'http://localhost/pankaj/theme/img/gallery/image1.jpg,http://localhost/pankaj/theme/img/gallery/image1.jpg,http://localhost/pankaj/theme/img/gallery/image4.jpg,http://localhost/pankaj/theme/img/gallery/image4.jpg,http://localhost/pankaj/theme/img/gallery/image5.jpg,http://localhost/pankaj/theme/img/gallery/image5.jpg,http://localhost/pankaj/theme/img/gallery/image7.jpg,http://localhost/pankaj/theme/img/gallery/image7.jpg', 'dasdsad wrwerew ewrewre', 'printing,framing', '0.00', '0.00', '0.00', '0.00', 1),
(2, 1, 'http://localhost/pankaj/theme/img/gallery/image2.jpg,http://localhost/pankaj/theme/img/gallery/image2.jpg,http://localhost/pankaj/theme/img/gallery/image6.jpg,http://localhost/pankaj/theme/img/gallery/image6.jpg,http://localhost/pankaj/theme/img/gallery/image8.jpg,http://localhost/pankaj/theme/img/gallery/image8.jpg,http://localhost/pankaj/theme/img/gallery/image3.jpg,http://localhost/pankaj/theme/img/gallery/image3.jpg', 'dsadad dsdsa adsad hgjhgjh dasdsad adsad', 'lamination,framing', '0.00', '0.00', '0.00', '0.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `printing_orders`
--

CREATE TABLE `printing_orders` (
  `id` int(150) NOT NULL,
  `order_no` varchar(100) NOT NULL,
  `title` varchar(150) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(80) NOT NULL,
  `lamination` varchar(10) DEFAULT NULL,
  `framing` varchar(10) DEFAULT NULL,
  `lamination_type` varchar(150) DEFAULT NULL,
  `framing_type` varchar(150) DEFAULT NULL,
  `lmcost` decimal(25,2) NOT NULL,
  `fmcost` decimal(25,2) NOT NULL,
  `order_date` date NOT NULL,
  `delivery_date` date NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `custatus` varchar(80) NOT NULL DEFAULT 'ordered',
  `printing_type` varchar(150) NOT NULL,
  `ptcost` decimal(25,2) NOT NULL,
  `delivery` varchar(10) NOT NULL,
  `distance` varchar(150) NOT NULL,
  `dccost` decimal(25,2) NOT NULL,
  `total` decimal(25,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `printing_orders`
--

INSERT INTO `printing_orders` (`id`, `order_no`, `title`, `customer_id`, `customer_name`, `lamination`, `framing`, `lamination_type`, `framing_type`, `lmcost`, `fmcost`, `order_date`, `delivery_date`, `status`, `custatus`, `printing_type`, `ptcost`, `delivery`, `distance`, `dccost`, `total`) VALUES
(1, '201705041', 'Tour Print', 1, 'Naveen', NULL, NULL, NULL, NULL, '0.00', '0.00', '2017-05-04', '2017-05-25', 'pending', 'ordered', '', '0.00', '', '', '0.00', '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `recovery_tokens`
--

CREATE TABLE `recovery_tokens` (
  `user_id` int(11) NOT NULL,
  `token` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `setting_id` int(1) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `logo2` varchar(255) NOT NULL,
  `site_name` varchar(55) NOT NULL,
  `language` varchar(20) NOT NULL,
  `default_warehouse` int(2) NOT NULL,
  `currency_prefix` varchar(3) NOT NULL,
  `default_invoice_type` int(2) NOT NULL,
  `default_tax_rate` int(2) NOT NULL,
  `rows_per_page` int(2) NOT NULL,
  `no_of_rows` int(2) NOT NULL,
  `total_rows` int(2) NOT NULL,
  `version` varchar(5) NOT NULL DEFAULT '1.2',
  `default_tax_rate2` int(11) NOT NULL DEFAULT '0',
  `dateformat` int(11) NOT NULL,
  `sales_prefix` varchar(20) NOT NULL,
  `quote_prefix` varchar(55) NOT NULL,
  `purchase_prefix` varchar(55) NOT NULL,
  `transfer_prefix` varchar(55) NOT NULL,
  `barcode_symbology` varchar(20) NOT NULL,
  `theme` varchar(20) NOT NULL,
  `product_serial` tinyint(4) NOT NULL,
  `default_discount` int(11) NOT NULL,
  `discount_option` tinyint(4) NOT NULL,
  `discount_method` tinyint(4) NOT NULL,
  `tax1` tinyint(4) NOT NULL,
  `tax2` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`setting_id`, `logo`, `logo2`, `site_name`, `language`, `default_warehouse`, `currency_prefix`, `default_invoice_type`, `default_tax_rate`, `rows_per_page`, `no_of_rows`, `total_rows`, `version`, `default_tax_rate2`, `dateformat`, `sales_prefix`, `quote_prefix`, `purchase_prefix`, `transfer_prefix`, `barcode_symbology`, `theme`, `product_serial`, `default_discount`, `discount_option`, `discount_method`, `tax1`, `tax2`) VALUES
(1, 'header_logo.png', 'logo-big.png', 'Picture Perfect', 'english', 0, 'INR', 2, 0, 10, 9, 0, '2.0', 0, 3, 'UBT', '0', '0', '0', '', 'green', 0, 1, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1, '127.0.0.1', 'administrator', '$2a$07$SeBknntpZror9uyftVopmu61qg0ms8Qv1yV6FG.kQOSM.9QhmTo36', '', 'admin@admin.com', '', NULL, NULL, NULL, 1268889823, 1494249479, 1, 'Administrator', '', 'ADMIN', '0'),
(2, '::1', 'rajesh@gmail.com', '$2y$08$FPQQl3.xSrGtQFRRjAPOP.Pvc5IydgChxRemM1J6FGnMcss1LqfWu', NULL, 'rajesh@gmail.com', '2898974369d942e7fb007939289da5c2255ce581', NULL, NULL, NULL, 1490958924, NULL, 0, 'Rajesh', 'kumar', 'CCTV STORE', '9996032650');

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 2, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `autologin`
--
ALTER TABLE `autologin`
  ADD PRIMARY KEY (`user`,`series`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_addresses`
--
ALTER TABLE `customer_addresses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `date_format`
--
ALTER TABLE `date_format`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deliveryfees`
--
ALTER TABLE `deliveryfees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dimensions`
--
ALTER TABLE `dimensions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `discounts`
--
ALTER TABLE `discounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`,`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `printing_orders`
--
ALTER TABLE `printing_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recovery_tokens`
--
ALTER TABLE `recovery_tokens`
  ADD PRIMARY KEY (`token`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`setting_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  ADD KEY `fk_users_groups_users1_idx` (`user_id`),
  ADD KEY `fk_users_groups_groups1_idx` (`group_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=257;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `customer_addresses`
--
ALTER TABLE `customer_addresses`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `date_format`
--
ALTER TABLE `date_format`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `deliveryfees`
--
ALTER TABLE `deliveryfees`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `dimensions`
--
ALTER TABLE `dimensions`
  MODIFY `id` int(150) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `discounts`
--
ALTER TABLE `discounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(150) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `printing_orders`
--
ALTER TABLE `printing_orders`
  MODIFY `id` int(150) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
